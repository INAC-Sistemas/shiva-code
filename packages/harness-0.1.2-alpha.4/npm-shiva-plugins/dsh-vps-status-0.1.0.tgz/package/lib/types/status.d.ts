/**
 * The `vps_status` wire contract: what the configured endpoint must answer,
 * how that answer is validated, and how it is rendered for a reader.
 *
 * The endpoint is a network boundary, so its JSON is validated here rather
 * than trusted — a typed interface says nothing about what a remote host
 * actually sends. Percentages are derived locally from the reported byte
 * counts, keeping one source of truth: the endpoint reports what it measured,
 * this module owns every number computed from it.
 */
/** One measured resource as the endpoint reports it. */
export interface UsageBytes {
    /** Total capacity in bytes; must be positive. */
    totalBytes: number;
    /** Bytes currently in use; must be zero or positive. */
    usedBytes: number;
}
/** One measured resource after the derived percentage is added. */
export interface Usage extends UsageBytes {
    /** `usedBytes / totalBytes` as a percentage, rounded to one decimal. */
    usedPct: number;
}
/** The endpoint's answer, validated. */
export interface VpsStatus {
    /** Filesystem usage. */
    disk: Usage;
    /** RAM usage. */
    memory: Usage;
}
/** Rejection of a malformed endpoint answer, carrying the offending field path. */
export declare class VpsStatusFormatError extends Error {
    constructor(path: string, detail: string);
}
/**
 * Validate a decoded endpoint answer.
 * @param raw - the decoded JSON body, however malformed.
 * @returns the validated status with derived percentages.
 * @throws VpsStatusFormatError on any contract violation.
 */
export declare function parseVpsStatus(raw: unknown): VpsStatus;
/**
 * Format a byte count for a human reader.
 * @param bytes - a non-negative finite byte count.
 * @returns the count in its largest whole unit, with one decimal above bytes.
 */
export declare function formatBytes(bytes: number): string;
/**
 * Render one validated status as the single line the model and the UI read.
 * @param status - the validated status.
 * @returns one line covering both resources.
 */
export declare function formatVpsStatus(status: VpsStatus): string;
