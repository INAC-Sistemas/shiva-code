import type { ClientContext } from '../context-types.ts';
/**
 * Keep the named tabs labelled in the active locale for as long as the
 * sidebar is present.
 * @param ctx - the browser cordis context.
 * @returns disposer restoring every title this installed.
 */
export declare function installTabTitles(ctx: ClientContext): () => void;
