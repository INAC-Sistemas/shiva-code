import type { ClientContext } from '../context-types.ts';
/**
 * Services required before mounting; provided by the shipped locale plugin.
 *
 * `betterSidebar` is deliberately absent: the tab relabelling waits for it
 * through `ctx.inject`, so a composition without that sidebar still gets the
 * languages.
 */
export declare const inject: string[];
/**
 * Client plugin body.
 * @param ctx - the browser cordis context carrying the locale service.
 */
export declare function apply(ctx: ClientContext): void;
