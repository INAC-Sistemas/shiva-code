/** Spanish: the panel's shared vocabulary and its smaller surfaces. */
export declare const core: {
    command: {
        'search.placeholder': string;
        'search.aria': string;
        'status.loading': string;
        'status.applying': string;
        'status.empty': string;
        'overlay.aria': string;
        'listbox.aria': string;
        'notice.imagesUnsupported': string;
    };
    common: {
        ok: string;
        cancel: string;
        close: string;
        copy: string;
        copied: string;
        retry: string;
        loading: string;
        'load.failed': string;
        submit: string;
        submitting: string;
        next: string;
        previous: string;
        skip: string;
        delete: string;
        edit: string;
        save: string;
        search: string;
        more: string;
        collapse: string;
        expand: string;
        back: string;
        unknown: string;
        none: string;
        truncated: string;
    };
    deliverables: {
        'produced.label': string;
        'produced.moreOne': string;
        'produced.more': string;
        'produced.open': string;
        'produced.showInFolder': string;
    };
    feedback: {
        'action.like': string;
        'action.likeActive': string;
        'action.dislike': string;
        'action.dislikeActive': string;
        'note.open': string;
        'note.dialog': string;
        'note.placeholder': string;
        'note.save': string;
        'note.cancel': string;
        'note.aria': string;
        'error.conflict': string;
        'error.load': string;
        'error.generic': string;
    };
    goal: {
        'phase.active': string;
        'phase.paused': string;
        'phase.blocked': string;
        'objective.aria': string;
        'commandInput.aria': string;
        'action.save': string;
        'action.cancel': string;
        'action.pause': string;
        'action.resume': string;
        'action.edit': string;
        'action.clear': string;
    };
    'permission.access': {
        'confirm.title': string;
        'confirm.description': string;
        'confirm.acknowledge': string;
        'confirm.cancel': string;
        'confirm.enable': string;
    };
    plan: {
        'chip.on.aria': string;
        'chip.on.title': string;
        'chip.off.aria': string;
        'chip.off.title': string;
    };
    reference: {
        'section.files': string;
        'section.sessions': string;
        'candidate.file': string;
        'candidate.folder': string;
        'candidate.session': string;
        'candidate.noCwd': string;
    };
    'session-log-download': {
        'dialog.preparingTitle': string;
        'dialog.preparingDescription': string;
        'dialog.successTitle': string;
        'dialog.successDescription': string;
        'dialog.errorTitle': string;
        'dialog.close': string;
        'dialog.commandFailed': string;
    };
    sidebar: {
        'session.new': string;
        'session.new.label': string;
        'toggle.open': string;
        'toggle.collapse': string;
    };
    skill: {
        'row.running': string;
        'row.failed': string;
        'row.stopped': string;
        'row.instructions': string;
        'menu.userOnly': string;
    };
    'slash.menu': {
        command: string;
        skill: string;
        subagent: string;
        loading: string;
        'suggestions.aria': string;
    };
};
