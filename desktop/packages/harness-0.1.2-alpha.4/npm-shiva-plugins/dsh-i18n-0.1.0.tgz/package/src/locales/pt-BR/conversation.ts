/** Brazilian Portuguese: the conversation surface — the panel's largest namespace. */

import type { LocaleBundle } from '../types.ts'

export const conversation = {
  conversation: {
    'hint.plan': 'descreva sua tarefa para gerar o plano',
    'hint.goal': 'descreva o objetivo de uma tarefa longa',
    'hint.goal.active': 'objetivo ativo — editar / pausar / retomar / limpar',
    'placeholder.plan': 'descreva sua tarefa para gerar o plano',
    'placeholder.default': 'Escreva para o agente',
    'placeholder.unavailable': 'Sessão indisponível',
    'placeholder.parentOffline': 'Sessão pai offline; não dá para enviar, mas você ainda pode parar a execução',
    'placeholder.hero': 'Descreva o que você quer construir',
    'placeholder.workspace': 'Escolha um workspace para começar',
    'input.commands': 'Comandos',
    'input.stop': 'Parar a geração',
    'input.send': 'Enviar mensagem',
    'placeholder.steerQueue': 'Cmd/Ctrl+Enter direciona todas as mensagens na fila',
    'input.accessMode': 'Modo de acesso, atual: {name}',

    'image.dropTitle': 'Arraste imagens para cá para adicioná-las',
    'image.dropDesc': 'Até {count} imagens, {size} cada',
    'image.dropBlocked': 'Não dá para adicionar imagens agora',
    'image.pending': 'Imagens pendentes',
    'image.openOriginal': 'Ver original',
    'image.openOriginalLabel': '{label}, clique para ver o original',
    'image.remove': 'Remover a imagem {name}',
    'image.scrollLeft': 'Rolar as imagens para a esquerda',
    'image.scrollRight': 'Rolar as imagens para a direita',
    'image.original': 'Imagem original',
    'image.label': 'Imagem',
    'image.loadFailed': 'A imagem falhou ao carregar; clique para tentar de novo',
    'image.loading': 'Carregando a imagem…',
    'image.preview': 'Prévia da imagem original',
    'image.closePreview': 'Fechar a prévia da imagem original',
    'image.unsupportedType': 'Só há suporte para imagens PNG, JPG, WebP e GIF',
    'image.tooMany': 'Uma mensagem pode incluir até {count} imagens',
    'image.fileTooLarge': 'Cada imagem precisa ser menor que {size}',
    'image.totalTooLarge': 'As imagens somam mais de {size}; remova algumas e tente de novo',
    'image.tooManyPixels': 'A resolução da imagem é alta demais; comprima-a e tente de novo',
    'image.dimensionTooLarge': 'Os lados da imagem podem ter no máximo {size}px; reduza-a e tente de novo',
    'image.modelUnsupported': 'O modelo atual não aceita imagens; troque por um que aceite',
    'image.sendFailed': 'Falha ao enviar as imagens ({reason}); adicione-as de novo e tente outra vez',

    'context.aria': '{percent} do contexto usado',
    'context.used': 'do contexto usado',
    'context.system': 'Prompt de sistema',
    'context.tools': 'Ferramentas',
    'context.messages': 'Mensagens',


    'settings.enter.title': 'Comportamento do Enter enquanto ocupado',
    'settings.enter.description': 'Só quando ocupado; Cmd/Ctrl+Enter usa o outro comportamento',
    'settings.enter.queue': 'Enfileirar',
    'settings.enter.steer': 'Direcionar',

    'access.confirm.title': 'Ativar acesso total?',
    'access.confirm.description': 'O acesso total reduz as etapas de confirmação e deixa o agente executar mais ações diretamente, inclusive operações sensíveis, alterações em arquivos e comandos externos. Use apenas quando confiar na tarefa atual.',
    'access.confirm.acknowledge': 'Entendo os riscos e quero continuar',
    'access.confirm.cancel': 'Cancelar',
    'access.confirm.enable': 'Ativar acesso total',

    'hero.headline': 'Rumo ao desconhecido',
    'hero.preview': 'Prévia',
    'hero.chooseWorkspace': 'Escolher workspace',
    'session.hierarchy': 'Hierarquia da sessão',

    'details.running': 'Rodando…',

    'todo.title': 'Tarefas',
    'todo.progress.done': '{done} concluídas',
    'todo.progress.active': '{active} em andamento',
    'todo.progress.pending': '{pending} pendentes',
    'todo.rowTitle': 'Atualizar a lista de tarefas',
    'todo.completed': '{done}/{total} concluídas',




    'command.imagesUnsupported': '/{command} não aceita imagens anexadas; remova-as antes',


    'ask.rowTitle': 'Fazer pergunta',
    'ask.waiting': 'aguardando',
    'ask.cancelled': 'cancelada',
    'ask.interrupted': 'interrompida',
    'ask.answered': '{answered}/{total} respondidas',

    'bash.running': 'Rodando',
    'bash.failed': 'Falhou',
    'bash.stopped': 'Parado',
    'row.running': 'Rodando',
    'row.failed': 'Falhou',
    'row.stopped': 'Parado',

    'queue.count': '{n} mensagens na fila',
    'queue.edit': 'Editar a mensagem na fila',
    'queue.edit.unsupported': 'Contém conteúdo que não é texto; a edição ainda não é suportada',
    'queue.save': 'Salvar a mensagem na fila',
    'queue.cancelEdit': 'Cancelar a edição',
    'queue.remove': 'Remover a mensagem da fila',
    'queue.steer': 'Direcionar a mensagem da fila',
    'queue.steer.unavailable': 'Direcionar só é possível enquanto o agente está rodando',
    'queue.editFailed': 'Falha ao editar: esta mensagem pode já ter começado a ser enviada.',
    'queue.removeFailed': 'Falha ao remover: esta mensagem pode já ter começado a ser enviada.',
    'queue.steerFailed': 'Falha ao direcionar. Tente de novo.',

    'terminal.signal': 'sinal {signal}',
    'terminal.exitCode': 'código de saída {code}',
    'terminal.running': 'Rodando',
    'terminal.failed': 'Falhou',
    'terminal.done': 'Pronto',
    'terminal.noOutput': 'Sem saída',
    'terminal.collapseAria': 'Recolher a saída',
    'terminal.expandAria': 'Expandir as {n} linhas restantes da saída',
    'terminal.expandRest': '… mais {n} linhas',
    'terminal.session': 'Terminal {sessionId}',
    'terminal.sendInput': '(enviar entrada)',

    // Tool card titles. Bash, Pwsh, Glob and Grep are the programs' own names
    // and stay as issued; Cordis is the framework's name.
    'tool.title.bash': 'Bash',
    'tool.title.pwsh': 'Pwsh',
    'tool.title.glob': 'Glob',
    'tool.title.grep': 'Grep',
    'tool.title.code': 'Código',
    'tool.title.edit': 'Editar',
    'tool.title.read': 'Ler',
    'tool.title.write': 'Escrever',
    'tool.title.search': 'Buscar',
    'tool.title.inspect': 'Inspecionar',
    'tool.title.generic': 'Chamada de ferramenta',
    'tool.title.webFetch': 'Buscar',
    'tool.title.webSearch': 'Pesquisar',
    'tool.title.runCordis': 'Executar plugin Cordis',
    'tool.title.stopCordis': 'Parar plugin Cordis',
    'tool.title.removeCordis': 'Remover plugin Cordis',

    // Column labels on a tool row: short enough to sit beside the value.
    'row.input': 'ENT',
    'row.output': 'SAÍ',
    'row.inspect': 'Inspecionar',

    'read.window': 'Mostrando {shown} de {total} linhas',
    'read.collapseAria': 'Recolher o conteúdo',
    'read.expandAria': 'Expandir mais {count} linhas',
    'read.expandRest': '… mais {count} linhas',

    'diff.files.one': '{count} arquivo',
    'diff.files.other': '{count} arquivos',
    'diff.collapseAria': 'Recolher o diff',
    'diff.expandAria': 'Expandir mais {count} linhas do diff',
    'diff.expandRest': '… mais {count} linhas',

    'search.matches': '{shown} ocorrências · {files} arquivos',
    'search.matches.truncated': 'Mostrando {shown} de {total} ocorrências · {files} arquivos',
    'search.paths': '{shown} caminhos',
    'search.paths.truncated': 'Mostrando {shown} de {total} caminhos',
    'search.noResults': 'Nenhum resultado',
    'search.collapseAria': 'Recolher os resultados',
    'search.expandAria': 'Expandir mais {count} linhas de resultado',
    'search.expandRest': '… mais {count} linhas',

    'web.http': 'HTTP',
    'web.noResults': 'Nenhum resultado encontrado',
    'web.contentTruncated': 'Conteúdo truncado',
    'web.sourcesTruncated': 'Lista de fontes truncada',

    'ask.skipped': 'Não respondido',
    'ask.cancelledDetail': 'Este conjunto de perguntas foi cancelado antes do envio das respostas.',
    'ask.interruptedDetail': 'Este conjunto de perguntas foi interrompido antes do envio das respostas.',

    'queue.image': 'Imagem da mensagem na fila',

    'access.preset.readOnly': 'Somente leitura',
    'access.preset.workspaceWrite': 'Escrita no workspace',
    'access.preset.fullAccess': 'Acesso total',
  },
  approval: {
    waiting: 'Aguardando aprovação',
    'detail.aria': 'Detalhes da aprovação',
    escalation: 'A ferramenta {toolName} pede execução privilegiada',
    reject: 'Recusar',
    allowOnce: 'Permitir uma vez',
  },
} satisfies LocaleBundle
