/** Spanish: the conversation surface — the panel's largest namespace. */

import type { LocaleBundle } from '../types.ts'

export const conversation = {
  conversation: {
    'hint.plan': 'describe tu tarea para generar el plan',
    'hint.goal': 'describe el objetivo de una tarea larga',
    'hint.goal.active': 'objetivo activo — editar / pausar / reanudar / borrar',
    'placeholder.plan': 'describe tu tarea para generar el plan',
    'placeholder.default': 'Escribe al agente',
    'placeholder.unavailable': 'Sesión no disponible',
    'placeholder.parentOffline': 'Sesión padre desconectada; no se puede enviar, pero aún puedes detener la ejecución',
    'placeholder.hero': 'Describe lo que quieres construir',
    'placeholder.workspace': 'Elige un workspace para empezar',
    'input.commands': 'Comandos',
    'input.stop': 'Detener la generación',
    'input.send': 'Enviar mensaje',
    'placeholder.steerQueue': 'Cmd/Ctrl+Enter dirige todos los mensajes en cola',
    'input.accessMode': 'Modo de acceso, actual: {name}',

    'image.dropTitle': 'Arrastra imágenes aquí para añadirlas',
    'image.dropDesc': 'Hasta {count} imágenes, {size} cada una',
    'image.dropBlocked': 'Ahora mismo no se pueden añadir imágenes',
    'image.pending': 'Imágenes pendientes',
    'image.openOriginal': 'Ver el original',
    'image.openOriginalLabel': '{label}, haz clic para ver el original',
    'image.remove': 'Quitar la imagen {name}',
    'image.scrollLeft': 'Desplazar las imágenes a la izquierda',
    'image.scrollRight': 'Desplazar las imágenes a la derecha',
    'image.original': 'Imagen original',
    'image.label': 'Imagen',
    'image.loadFailed': 'La imagen no se pudo cargar; haz clic para reintentar',
    'image.loading': 'Cargando la imagen…',
    'image.preview': 'Vista previa de la imagen original',
    'image.closePreview': 'Cerrar la vista previa de la imagen original',
    'image.unsupportedType': 'Solo se admiten imágenes PNG, JPG, WebP y GIF',
    'image.tooMany': 'Un mensaje puede incluir hasta {count} imágenes',
    'image.fileTooLarge': 'Cada imagen debe ser menor de {size}',
    'image.totalTooLarge': 'Las imágenes suman más de {size}; quita algunas e inténtalo de nuevo',
    'image.tooManyPixels': 'La resolución de la imagen es demasiado alta; comprímela e inténtalo de nuevo',
    'image.dimensionTooLarge': 'Los lados de la imagen pueden medir como mucho {size}px; redúcela e inténtalo de nuevo',
    'image.modelUnsupported': 'El modelo actual no admite imágenes; cambia a uno que sí',
    'image.sendFailed': 'Error al enviar las imágenes ({reason}); vuelve a añadirlas e inténtalo otra vez',

    'context.aria': '{percent} del contexto usado',
    'context.used': 'del contexto usado',
    'context.system': 'Prompt del sistema',
    'context.tools': 'Herramientas',
    'context.messages': 'Mensajes',


    'settings.enter.title': 'Comportamiento de Enter mientras está ocupado',
    'settings.enter.description': 'Solo cuando está ocupado; Cmd/Ctrl+Enter usa el otro comportamiento',
    'settings.enter.queue': 'Poner en cola',
    'settings.enter.steer': 'Dirigir',

    'access.confirm.title': '¿Activar acceso total?',
    'access.confirm.description': 'El acceso total reduce los pasos de confirmación y permite al agente realizar más acciones directamente, incluidas operaciones sensibles, cambios en archivos y comandos externos. Úsalo solo cuando confíes en la tarea actual.',
    'access.confirm.acknowledge': 'Entiendo los riesgos y quiero continuar',
    'access.confirm.cancel': 'Cancelar',
    'access.confirm.enable': 'Activar acceso total',

    'hero.headline': 'Hacia lo desconocido',
    'hero.preview': 'Vista previa',
    'hero.chooseWorkspace': 'Elegir workspace',
    'session.hierarchy': 'Jerarquía de la sesión',

    'details.running': 'En ejecución…',

    'todo.title': 'Tareas',
    'todo.progress.done': '{done} completadas',
    'todo.progress.active': '{active} en curso',
    'todo.progress.pending': '{pending} pendientes',
    'todo.rowTitle': 'Actualizar la lista de tareas',
    'todo.completed': '{done}/{total} completadas',




    'command.imagesUnsupported': '/{command} no acepta imágenes adjuntas; quítalas primero',


    'ask.rowTitle': 'Hacer una pregunta',
    'ask.waiting': 'esperando',
    'ask.cancelled': 'cancelada',
    'ask.interrupted': 'interrumpida',
    'ask.answered': '{answered}/{total} respondidas',

    'bash.running': 'En ejecución',
    'bash.failed': 'Falló',
    'bash.stopped': 'Detenido',
    'row.running': 'En ejecución',
    'row.failed': 'Falló',
    'row.stopped': 'Detenido',

    'queue.count': '{n} mensajes en cola',
    'queue.edit': 'Editar el mensaje en cola',
    'queue.edit.unsupported': 'Contiene contenido que no es texto; la edición todavía no está admitida',
    'queue.save': 'Guardar el mensaje en cola',
    'queue.cancelEdit': 'Cancelar la edición',
    'queue.remove': 'Quitar el mensaje de la cola',
    'queue.steer': 'Dirigir el mensaje de la cola',
    'queue.steer.unavailable': 'Dirigir solo es posible mientras el agente está en ejecución',
    'queue.editFailed': 'Error al editar: puede que este mensaje ya haya empezado a enviarse.',
    'queue.removeFailed': 'Error al quitarlo: puede que este mensaje ya haya empezado a enviarse.',
    'queue.steerFailed': 'Error al dirigirlo. Inténtalo de nuevo.',

    'terminal.signal': 'señal {signal}',
    'terminal.exitCode': 'código de salida {code}',
    'terminal.running': 'En ejecución',
    'terminal.failed': 'Falló',
    'terminal.done': 'Listo',
    'terminal.noOutput': 'Sin salida',
    'terminal.collapseAria': 'Contraer la salida',
    'terminal.expandAria': 'Expandir las {n} líneas restantes de la salida',
    'terminal.expandRest': '… {n} líneas más',
    'terminal.session': 'Terminal {sessionId}',
    'terminal.sendInput': '(enviar entrada)',

    // Tool card titles. Bash, Pwsh, Glob and Grep are the programs' own names
    // and stay as issued; Cordis is the framework's name.
    'tool.title.bash': 'Bash',
    'tool.title.pwsh': 'Pwsh',
    'tool.title.glob': 'Glob',
    'tool.title.grep': 'Grep',
    'tool.title.code': 'Código',
    'tool.title.edit': 'Editar',
    'tool.title.read': 'Leer',
    'tool.title.write': 'Escribir',
    'tool.title.search': 'Buscar',
    'tool.title.inspect': 'Inspeccionar',
    'tool.title.generic': 'Llamada a herramienta',
    'tool.title.webFetch': 'Obtener',
    'tool.title.webSearch': 'Buscar',
    'tool.title.runCordis': 'Ejecutar plugin de Cordis',
    'tool.title.stopCordis': 'Detener plugin de Cordis',
    'tool.title.removeCordis': 'Eliminar plugin de Cordis',

    // Column labels on a tool row: short enough to sit beside the value.
    'row.input': 'ENT',
    'row.output': 'SAL',
    'row.inspect': 'Inspeccionar',

    'read.window': 'Mostrando {shown} de {total} líneas',
    'read.collapseAria': 'Contraer el contenido',
    'read.expandAria': 'Expandir {count} líneas más',
    'read.expandRest': '… {count} líneas más',

    'diff.files.one': '{count} archivo',
    'diff.files.other': '{count} archivos',
    'diff.collapseAria': 'Contraer el diff',
    'diff.expandAria': 'Expandir {count} líneas más del diff',
    'diff.expandRest': '… {count} líneas más',

    'search.matches': '{shown} coincidencias · {files} archivos',
    'search.matches.truncated': 'Mostrando {shown} de {total} coincidencias · {files} archivos',
    'search.paths': '{shown} rutas',
    'search.paths.truncated': 'Mostrando {shown} de {total} rutas',
    'search.noResults': 'Sin resultados',
    'search.collapseAria': 'Contraer los resultados',
    'search.expandAria': 'Expandir {count} líneas más de resultados',
    'search.expandRest': '… {count} líneas más',

    'web.http': 'HTTP',
    'web.noResults': 'No se encontraron resultados',
    'web.contentTruncated': 'Contenido truncado',
    'web.sourcesTruncated': 'Lista de fuentes truncada',

    'ask.skipped': 'Sin responder',
    'ask.cancelledDetail': 'Este conjunto de preguntas se canceló antes de enviar las respuestas.',
    'ask.interruptedDetail': 'Este conjunto de preguntas se interrumpió antes de enviar las respuestas.',

    'queue.image': 'Imagen del mensaje en cola',

    'access.preset.readOnly': 'Solo lectura',
    'access.preset.workspaceWrite': 'Escritura en el workspace',
    'access.preset.fullAccess': 'Acceso total',
  },
  approval: {
    waiting: 'Esperando aprobación',
    'detail.aria': 'Detalles de la aprobación',
    escalation: 'La herramienta {toolName} solicita ejecución privilegiada',
    reject: 'Rechazar',
    allowOnce: 'Permitir una vez',
  },
} satisfies LocaleBundle
