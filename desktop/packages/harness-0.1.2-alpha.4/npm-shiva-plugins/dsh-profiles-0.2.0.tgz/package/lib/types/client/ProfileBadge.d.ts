import type { ReactNode } from 'react';
import type { ProfileStore } from './store.ts';
/**
 * The first two characters of a profile name, for the collapsed sidebar.
 * @param name - the profile name.
 * @returns an uppercase mark, or `··` for an empty name.
 */
export declare function profileMark(name: string): string;
/** Props of {@link ProfileBadge}. */
export interface ProfileBadgeProps {
    /** Shared state with the gate: what is materialized, and whether to show the picker. */
    store: ProfileStore;
    /** Whether the sidebar is expanded; collapsed shows the mark alone. */
    wide: boolean;
}
/**
 * The profile row.
 * @param props - the shared store and the sidebar width.
 * @returns the row.
 */
export declare function ProfileBadge({ store, wide }: ProfileBadgeProps): ReactNode;
