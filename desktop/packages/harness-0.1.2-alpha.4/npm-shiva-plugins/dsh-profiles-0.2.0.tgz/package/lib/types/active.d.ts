import type { ActiveProfile } from './wire.ts';
/** Path of the selection file, relative to the harness home. */
export declare const ACTIVE_PROFILE_FILE: string;
/**
 * Read the materialized selection.
 *
 * Every failure reads as "no selection". The desktop shell reads the same file
 * with the same rule ({@link readActiveProfilePlugins} in `harness-runtime.ts`),
 * and both must agree: refusing to start over a truncated file would be worse
 * than starting with everything enabled, which is where the user was before
 * choosing anything.
 * @param dshHome - the harness home directory.
 * @returns the recorded selection, or null when none is readable.
 */
export declare function readActiveProfile(dshHome: string): Promise<ActiveProfile | null>;
/**
 * Record the materialized selection.
 *
 * Written to a sibling temporary file and renamed, because the desktop shell
 * reads this file at spawn: a partial write would look like a profile with no
 * plugins, which is a real and very different choice.
 * @param dshHome - the harness home directory.
 * @param active - the selection to record.
 */
export declare function writeActiveProfile(dshHome: string, active: ActiveProfile): Promise<void>;
