import type { ReactNode } from 'react';
import type { ProfileStore } from './store.ts';
/** Selector of the button the workspace-package patch marks. */
export declare const ADD_WORKSPACE_SELECTOR = "[data-dsh-action=\"add-workspace\"]";
/** The half of the guard the prompt drives. */
export interface AddWorkspaceGuard {
    /** Run the intercepted click through to the workspace package. */
    proceed(): void;
    /** Remove the listener. */
    dispose(): void;
}
/**
 * Intercept clicks on the add-workspace button and open the prompt instead.
 * @param root - where to listen, `document` in the browser.
 * @param store - the shared profile state; its prompt flag opens the modal.
 * @returns the guard, whose `proceed()` replays the last intercepted click.
 */
export declare function guardAddWorkspace(root: EventTarget, store: ProfileStore): AddWorkspaceGuard;
/** Props of {@link WorkspacePrompt}. */
export interface WorkspacePromptProps {
    store: ProfileStore;
    guard: AddWorkspaceGuard;
}
/**
 * The modal.
 * @param props - the shared store and the guard to resume through.
 * @returns the modal while the question is open, otherwise null.
 */
export declare function WorkspacePrompt({ store, guard }: WorkspacePromptProps): ReactNode;
