import type { ClientContext } from './context-types.ts';
export { ProfileBadge, profileMark } from './ProfileBadge.tsx';
export type { ProfileBadgeProps } from './ProfileBadge.tsx';
export { ProfileGate, planFrom } from './ProfileGate.tsx';
export type { ProfileGateProps } from './ProfileGate.tsx';
export { ProfileStore } from './store.ts';
export type { ProfileSnapshot } from './store.ts';
export { fetchState, selectProfile } from './api.ts';
export type { ClientContext, LoginSessionFace, SlotComponent, SlotRegistry } from './context-types.ts';
/** The seat the picker covers the app from. */
export declare const OVERLAY_SLOT = "shell.overlay";
/**
 * The seat the profile row sits in: the sidebar foot, above the account row.
 *
 * A stacking list, so this row claims the full width beside its neighbours
 * rather than competing with them inside one flex row — the reason
 * `dsh-user-menu` uses the same seat.
 */
export declare const FOOTER_SLOT = "sidebar.footer.below";
/** This entry's cell key in those list slots. */
export declare const ENTRY_ID = "dsh-profiles";
/** Ascending order in the sidebar foot; above `dsh-user-menu`'s account row at 100. */
export declare const FOOTER_ORDER = 90;
/**
 * Ascending display order.
 *
 * Below dsh-login's 10_000: while nobody is signed in there is no roster to
 * pick from, so the login screen has to be the one covering the app.
 */
export declare const ENTRY_ORDER = 9999;
/**
 * Services required before mounting.
 *
 * `loginSession` is a hard requirement, not a soft read: without a session
 * there is no roster, and a picker that mounted anyway would show an empty list
 * that reads as "you have no profiles".
 */
export declare const inject: string[];
/**
 * Client plugin body.
 *
 * Two surfaces over one store. The gate opens itself when nothing is
 * materialized; the badge in the sidebar foot opens it on demand, and is the
 * only way to SWITCH — without it a machine that already has a profile never
 * sees the picker again, and changing profiles would mean the plugin manager's
 * dashboard plus a reload.
 * @param ctx - the browser cordis context carrying the slot registry and session.
 */
export declare function apply(ctx: ClientContext): void;
