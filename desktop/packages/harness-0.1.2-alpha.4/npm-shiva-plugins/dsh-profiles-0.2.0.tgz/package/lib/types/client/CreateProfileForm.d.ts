import type { ReactNode } from 'react';
import type { ProfileSummary } from '../wire.ts';
/** Props of {@link CreateProfileForm}. */
export interface CreateProfileFormProps {
    /** Runs with the created profile, which the picker then makes active. */
    onCreated: (profile: ProfileSummary) => void;
    /** Runs when the person backs out; the picker returns to the roster. */
    onCancel: () => void;
}
/**
 * The authoring form.
 * @param props - see {@link CreateProfileFormProps}.
 * @returns the form element tree.
 */
export declare function CreateProfileForm({ onCreated, onCancel }: CreateProfileFormProps): ReactNode;
