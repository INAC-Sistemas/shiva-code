/**
 * The inline style vocabulary the picker and the authoring form share.
 *
 * Inline rather than a CSS module so the bundle carries no CSS pipeline; every
 * value is a DSH design token, so the screens follow the active theme. They
 * live in one module because the two screens are one dialog to the person using
 * it — a card that changed its padding or its ink between "choose" and "create"
 * would read as two products.
 * @module dsh-profiles/client/styles
 */
import type { CSSProperties } from 'react';
/**
 * Nothing materialized yet: this is a gate, not a dialog, so it covers the app
 * outright the way the login screen does. There is nothing usable behind it.
 */
export declare const BACKDROP_GATE: CSSProperties;
/**
 * A deliberate switch: the app behind stays running and cancellable, so this is
 * the shipped modal mask (`ui-primitives/Modal.module.css`) rather than an
 * opaque cover.
 */
export declare const BACKDROP_MASK: CSSProperties;
/**
 * The dialog card, filled with the shipped dialog tokens.
 *
 * The fill is not optional: without it the card is transparent and the picker
 * reads as text floating on whatever is behind, which is exactly what a mask
 * backdrop makes visible.
 */
export declare const CARD: CSSProperties;
/**
 * The same card, holding the authoring form.
 *
 * Wider because the form carries the whole catalog: at the roster's width the
 * skill lines would be more ellipsis than text. It is still a dialog, so the
 * width is capped rather than fluid.
 */
export declare const CARD_WIDE: CSSProperties;
export declare const TITLE: CSSProperties;
export declare const SUBTITLE: CSSProperties;
export declare const ROW: CSSProperties;
export declare const ROW_HINT: CSSProperties;
/** The row of the profile already in force, so a switch shows what it moves from. */
export declare const ROW_CURRENT: CSSProperties;
export declare const SECONDARY: CSSProperties;
/** The one committing action of a screen; every other control stays secondary. */
export declare const PRIMARY: CSSProperties;
export declare const NOTE: CSSProperties;
export declare const ERROR: CSSProperties;
/** A labelled group of the authoring form. */
export declare const FIELD: CSSProperties;
export declare const LABEL: CSSProperties;
export declare const INPUT: CSSProperties;
/**
 * The catalog boxes: bounded and scrolling, so a long library cannot push the
 * dialog's own buttons past the bottom of the screen.
 */
export declare const CHECK_BOX: CSSProperties;
export declare const CHECK_ROW: CSSProperties;
/** The text column of a checkbox row; `minWidth: 0` is what lets the hint clip. */
export declare const CHECK_TEXT: CSSProperties;
/** One line, clipped: the catalog's hints are prose, and the dialog is not. */
export declare const CHECK_HINT: CSSProperties;
/** Marks a plugin whose row only enters or leaves the process at boot. */
export declare const BADGE: CSSProperties;
/** The committing row of the authoring form. */
export declare const FOOTER: CSSProperties;
