import type { CreateResult, ProfileCatalog, ProfileDraft, ProfileState, SelectResult } from '../wire.ts';
/**
 * Read the roster and this machine's selection.
 * @param signal - aborts the request when the gate unmounts.
 * @returns the state, or the signed-out state when anything goes wrong —
 * an unreachable host half must leave the picker waiting, not assert that the
 * user has no profiles.
 */
export declare function fetchState(signal?: AbortSignal): Promise<ProfileState>;
/**
 * Make one profile the active one.
 * @param profileId - the profile to select.
 * @returns the recorded selection, or the reason it did not happen.
 */
export declare function selectProfile(profileId: string): Promise<SelectResult>;
/**
 * Read what a new profile can be built from.
 * @param signal - aborts the request when the form unmounts.
 * @returns the catalog, or `undefined` when it could not be read — the form
 * shows that as a failure to load rather than as an empty library, which would
 * invite authoring a profile that grants nothing.
 */
export declare function fetchCatalog(signal?: AbortSignal): Promise<ProfileCatalog | undefined>;
/**
 * Author one profile.
 * @param draft - the profile to create.
 * @returns the created profile, or the reason it was refused.
 */
export declare function createProfile(draft: ProfileDraft): Promise<CreateResult>;
