import type { ProfileState, SelectResult } from '../wire.ts';
/**
 * Read the roster and this machine's selection.
 * @param signal - aborts the request when the gate unmounts.
 * @returns the state, or the signed-out state when anything goes wrong —
 * an unreachable host half must leave the picker waiting, not assert that the
 * user has no profiles.
 */
export declare function fetchState(signal?: AbortSignal): Promise<ProfileState>;
/**
 * Make one profile the active one.
 * @param profileId - the profile to select.
 * @returns the recorded selection, or the reason it did not happen.
 */
export declare function selectProfile(profileId: string): Promise<SelectResult>;
