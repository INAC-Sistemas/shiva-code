import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { ACTIVE_PROFILE_FILE, readActiveProfile, writeActiveProfile } from './active.ts';
export { assertTimeout, resolveEndpoint } from './config.ts';
export { hostPlaneDiffers, knownPlugins, PLUGIN_ROWS, SELECT_ROUTE, STATE_ROUTE, } from './wire.ts';
export type { ActiveProfile, PluginPlane, ProfileState, ProfileSummary, SelectResult, } from './wire.ts';
/** Loader-visible plugin name; the entry `id` in cordis.patch.yml stays independent. */
export declare const name = "dsh-profiles";
/** Requires the HTTP route registry (`ctx.webServer`). */
export declare const inject: string[];
/** Plugin config: where the roster lives, and how long to wait for it. */
export interface Config {
    /** Full URL listing the signed-in user's profiles, requested verbatim. */
    profilesEndpoint?: string;
    /** Full URL that makes one profile active, requested verbatim. */
    activeEndpoint?: string;
    /** Full URL answering the active profile's spec, requested verbatim. */
    specEndpoint?: string;
    /** Deadline for each forwarded request, in milliseconds. */
    timeoutMs?: number;
    /** Harness home; the selection is recorded under it. Defaults to `$DSH_HOME`. */
    dshHome?: string;
}
export declare const Config: z<Config>;
/**
 * Register the two routes.
 * @param ctx - the host cordis context.
 * @param config - the validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
