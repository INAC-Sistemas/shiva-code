import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { ACTIVE_PROFILE_FILE, readActiveProfile, writeActiveProfile } from './active.ts';
export { assertTimeout, resolveEndpoint } from './config.ts';
export { CATALOG_ROUTE, CREATE_ROUTE, hostPlaneDiffers, knownPlugins, narrowCatalogPlugins, PLUGIN_ROWS, SELECT_ROUTE, STATE_ROUTE, } from './wire.ts';
export type { ActiveProfile, CreateResult, PluginOption, PluginPlane, ProfileCatalog, ProfileDraft, ProfileState, ProfileSummary, SelectResult, SkillOption, } from './wire.ts';
/** Loader-visible plugin name; the entry `id` in cordis.patch.yml stays independent. */
export declare const name = "dsh-profiles";
/** Requires the HTTP route registry (`ctx.webServer`). */
export declare const inject: string[];
/** Plugin config: where the roster lives, and how long to wait for it. */
export interface Config {
    /**
     * Full URL listing the signed-in user's profiles, requested verbatim.
     *
     * Also where a new profile is posted: creating one is a POST on the same
     * collection, so there is no second URL to keep in step with this one.
     */
    profilesEndpoint?: string;
    /** Full URL that selects one profile for the signed-in user, requested verbatim. */
    selectedEndpoint?: string;
    /** Full URL answering the selected profile's spec, requested verbatim. */
    specEndpoint?: string;
    /** Full URL answering what a new profile can be built from, requested verbatim. */
    catalogEndpoint?: string;
    /** Deadline for each forwarded request, in milliseconds. */
    timeoutMs?: number;
    /** Harness home; the selection is recorded under it. Defaults to `$DSH_HOME`. */
    dshHome?: string;
}
export declare const Config: z<Config>;
/**
 * Register the routes.
 * @param ctx - the host cordis context.
 * @param config - the validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
