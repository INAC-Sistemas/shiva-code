import type { ReactNode } from 'react';
import type { LoginSessionFace } from './context-types.ts';
import type { ProfileStore } from './store.ts';
import type { ProfileState, ProfileSummary } from '../wire.ts';
/** What the gate is doing right now. */
type Phase = {
    kind: 'reading';
} | {
    kind: 'choosing';
    profiles: ProfileSummary[];
    error?: string;
} | {
    kind: 'creating';
} | {
    kind: 'selecting';
} | {
    kind: 'restarting';
    name: string;
} | {
    kind: 'restart';
    name: string;
} | {
    kind: 'done';
};
/** Props of {@link ProfileGate}. */
export interface ProfileGateProps {
    /** The read face of `ctx.loginSession`; the gate stays out of the way until it reports a session. */
    session: LoginSessionFace;
    /** Shared state with the sidebar badge, which is how a deliberate switch opens this. */
    store: ProfileStore;
}
/**
 * Decide what the gate should do from one reading of the state.
 * @param state - the answer from the host half.
 * @returns the phase to enter, and the profile to materialize when there is one.
 */
export declare function planFrom(state: ProfileState): {
    phase: Phase;
    materialize?: string;
};
/**
 * The picker.
 * @param props - the login session face.
 * @returns the cover, or null once a profile is materialized.
 */
export declare function ProfileGate({ session, store }: ProfileGateProps): ReactNode;
export {};
