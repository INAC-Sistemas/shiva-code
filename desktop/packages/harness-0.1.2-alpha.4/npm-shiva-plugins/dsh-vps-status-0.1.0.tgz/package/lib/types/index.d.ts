/**
 * dsh-vps-status: a model-facing `vps_status` tool over one configured HTTP
 * endpoint.
 *
 * Host-only by design — the package declares no `dsh.client`, so the web shell
 * serves no bundle for it and nothing of this plugin reaches a browser. The
 * model sees the tool name, its description and its result; the endpoint's
 * implementation stays wherever it is deployed.
 *
 * The request is authenticated as the signed-in user: dsh-login records the
 * granted session as a credential record, and this plugin reads it once per
 * call. There is no machine credential to configure, and no session of its own
 * to keep — with nobody signed in the tool refuses and says so, rather than
 * asking the endpoint anonymously.
 *
 * One entry serves one host: mount the plugin once per machine to watch, each
 * row carrying its own `id` and `endpoint`.
 * @module dsh-vps-status
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export type { Usage, UsageBytes, VpsStatus } from './status.ts';
export { formatBytes, formatVpsStatus, parseVpsStatus, VpsStatusFormatError } from './status.ts';
/** Loader-visible plugin name; the entry `id` in cordis.patch.yml stays independent. */
export declare const name = "dsh-vps-status";
/** Requires the tool registry (`ctx.tools`). */
export declare const inject: string[];
/** Plugin config: which endpoint to read and how long to wait for it. */
export interface Config {
    /**
     * Full URL of the status resource, not a base — it is requested verbatim, so
     * a path is preserved (`https://vps1.example.com/api/status`).
     */
    endpoint: string;
    /** Tool name registered on `ctx.tools`; rename it when several hosts are mounted. */
    toolName?: string;
    /** Text the model reads to decide when to call the tool. */
    description?: string;
    /**
     * Static headers added to the request (a gateway key, a tenant id).
     * `authorization` is rejected: it carries the signed-in user's session and
     * has one source. The plugin's own `accept` is applied last and cannot be
     * overridden — the endpoint answers JSON or the result is rejected anyway.
     */
    headers?: Record<string, string>;
    /** Request deadline in milliseconds. */
    timeoutMs?: number;
}
export declare const Config: z<Config>;
/**
 * What the model is told when the plugin manager refuses this tool because the
 * user's selected profile does not include the plugin.
 */
export declare const NOT_IN_PROFILE_TEXT: string;
/**
 * Register the tool.
 *
 * Failure text is written for its actual reader — the model — so a terminal
 * failure says not to retry. Without that, a plain status code invites the
 * model to call again in a loop.
 * @param ctx - host cordis context carrying the tool registry.
 * @param config - validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
