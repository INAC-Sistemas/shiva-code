/**
 * The light tests each step runs before it saves anything.
 *
 * Every probe spends at most one small request, and each answers a message
 * written for the person, never a stack. A model listing is not a test: most
 * catalogs are public or shipped with the adapter, so a wrong key would pass.
 * @module dsh-setup/probes
 */
import type { LlmFace } from './services.ts';
/** A probe outcome. */
export type ProbeResult = {
    ok: true;
} | {
    ok: false;
    message: string;
};
/** The `fetch` a probe calls; injected so tests need no network. */
export type FetchLike = (url: string, init: RequestInit) => Promise<Response>;
/**
 * Join an API base and a path without doubling the slash.
 * @param base - the base URL the person typed or a preset supplied.
 * @param path - the path starting with `/`.
 * @returns the full URL.
 */
export declare function joinUrl(base: string, path: string): string;
/**
 * Whether a base URL is one the probes may call.
 * @param base - the typed base URL.
 * @returns true for an absolute http or https URL.
 */
export declare function isHttpUrl(base: string): boolean;
/**
 * Send one tiny chat request through the harness itself, which is the only
 * test that holds for every adapter: it resolves the stored credential, the
 * route and the model exactly the way a conversation will.
 * @param llm - the LLM runtime.
 * @param provider - the registered route.
 * @param model - the model id.
 * @param timeoutMs - the deadline for the whole request.
 * @returns whether the route answered.
 */
export declare function probeChat(llm: LlmFace, provider: string, model: string, timeoutMs: number): Promise<ProbeResult>;
/**
 * Check an OpenRouter key against the endpoint that describes the key itself.
 * @param fetchImpl - the fetch to call.
 * @param baseUrl - the OpenRouter API base.
 * @param apiKey - the key under test.
 * @param timeoutMs - the deadline.
 * @returns whether OpenRouter accepted the key.
 */
export declare function probeOpenRouterKey(fetchImpl: FetchLike, baseUrl: string, apiKey: string, timeoutMs: number): Promise<ProbeResult>;
/**
 * Embed one word, which proves the endpoint, the key and the model together
 * and reports the vector width OpenViking has to be configured with.
 * @param fetchImpl - the fetch to call.
 * @param base - the OpenAI-compatible API base.
 * @param apiKey - the key, or empty for an endpoint without one.
 * @param model - the embedding model.
 * @param timeoutMs - the deadline.
 * @returns the embedding width, or why it failed.
 */
export declare function probeEmbedding(fetchImpl: FetchLike, base: string, apiKey: string, model: string, timeoutMs: number): Promise<{
    ok: true;
    dimension: number;
} | {
    ok: false;
    message: string;
}>;
/**
 * Ask a vision-language model for one short completion.
 * @param fetchImpl - the fetch to call.
 * @param base - the OpenAI-compatible API base.
 * @param apiKey - the key, or empty for an endpoint without one.
 * @param model - the model.
 * @param timeoutMs - the deadline.
 * @returns whether the endpoint answered.
 */
export declare function probeCompletion(fetchImpl: FetchLike, base: string, apiKey: string, model: string, timeoutMs: number): Promise<ProbeResult>;
