/**
 * The routes behind the wizard.
 *
 * Nothing here invents storage. The chat key goes to the credentials service
 * under the reference the chat route's settings profile names, the chat model
 * to `agent-default-model`, the image key to `OPENROUTER_API_KEY` or `FAL_KEY`,
 * and the completion marker to the `shiva-setup` settings section. The image
 * model and the OpenViking endpoints are written by the browser through those
 * plugins' own routes, so each tool keeps a single writer for its settings.
 *
 * A key is kept only after its test passed. The chat test has to run with the
 * key stored — the adapter resolves it from the credentials service — so a
 * failed chat test puts back whatever the reference held before.
 * @module dsh-setup/handler
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { FetchLike } from './probes.ts';
import type { SetupServices } from './services.ts';
/** Tunables of the routes, resolved from the plugin config. */
export interface HandlerOptions {
    /** Deadline of each probe, in milliseconds. */
    timeoutMs: number;
    /** OpenRouter API base the image key is checked against. */
    openrouterBaseUrl: string;
    /** How long a newly configured chat route may take to register, in milliseconds. */
    routeWaitMs: number;
    /** The fetch the probes call. */
    fetch: FetchLike;
}
/**
 * Create the prefix handler serving every wizard route.
 * @param services - the host services, read per request.
 * @param options - the resolved tunables.
 * @returns the handler to register under `/setup/api`.
 */
export declare function createSetupHandler(services: SetupServices, options: HandlerOptions): (request: IncomingMessage, response: ServerResponse) => Promise<void>;
