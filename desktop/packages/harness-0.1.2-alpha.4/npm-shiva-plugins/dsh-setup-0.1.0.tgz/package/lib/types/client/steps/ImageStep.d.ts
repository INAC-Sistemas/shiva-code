import type { ReactNode } from 'react';
import type { AssetsStatus } from '../api.ts';
import type { SetupState } from '../../wire.ts';
/** Props of {@link ImageStep}. */
export interface ImageStepProps {
    /** `dsh-assets`' saved settings. */
    assets: AssetsStatus;
    /** Which image keys already resolve. */
    keys: SetupState['imageKeys'];
    /**
     * Called once an image model and its key are saved.
     * @param label - what the summary shows.
     */
    onDone: (label: string) => void;
    /** Return to the previous step. */
    onBack: () => void;
}
/**
 * Render the image step.
 * @param props - the saved settings, key facts and navigation callbacks.
 * @returns the step body and actions.
 */
export declare function ImageStep({ assets, keys, onDone, onBack }: ImageStepProps): ReactNode;
