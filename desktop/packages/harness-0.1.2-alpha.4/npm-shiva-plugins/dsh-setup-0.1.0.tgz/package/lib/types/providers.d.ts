/**
 * The providers each wizard step offers.
 *
 * The chat list names routes; a route only reaches the wizard when an LLM
 * adapter declares it configurable, so an entry this harness cannot serve is
 * dropped by the host rather than shown. The memory presets mirror the ones
 * `dsh-openviking`'s own Memory tab offers, so the two surfaces write the same
 * settings.
 *
 * This module must stay free of Node.js and React value imports: the browser
 * bundle compiles it.
 * @module dsh-setup/providers
 */
import type { ImageProvider } from './wire.ts';
/** One chat route offered, in display order. */
export interface ChatProviderEntry {
    provider: string;
    displayName: string;
    kind: string;
}
/** Chat routes the first step offers, most common first. */
export declare const CHAT_PROVIDERS: readonly ChatProviderEntry[];
/**
 * Derive the credential reference a route stores its key under when its
 * settings profile names none — the same rule the Models page applies, so a key
 * saved here is the one that page shows as configured.
 * @param provider - provider route id (e.g. `minimax-cn`).
 * @returns the reference (e.g. `MINIMAX_CN_API_KEY`).
 */
export declare function deriveKeyRef(provider: string): string;
/** One image provider offered. */
export interface ImageProviderEntry {
    provider: ImageProvider;
    label: string;
    hint: string;
}
/** Image providers `dsh-assets` generates through. */
export declare const IMAGE_PROVIDERS: readonly ImageProviderEntry[];
/** One OpenViking endpoint preset. */
export interface MemoryPreset {
    provider: string;
    label: string;
    /** Prefilled base URL; empty means the person types one. */
    base: string;
    /** Whether the endpoint takes a key at all. */
    needsKey: boolean;
    hint: string;
}
/** Endpoint presets for the memory step. */
export declare const MEMORY_PRESETS: readonly MemoryPreset[];
