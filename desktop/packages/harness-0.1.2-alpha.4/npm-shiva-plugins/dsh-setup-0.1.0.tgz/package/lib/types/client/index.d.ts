import type { ClientContext } from './context-types.ts';
export { SetupGate } from './SetupGate.tsx';
export type { SetupGateProps } from './SetupGate.tsx';
export type { ClientContext, LoginSessionFace, SlotComponent, SlotRegistry } from './context-types.ts';
/** The seat the wizard covers the app from. */
export declare const OVERLAY_SLOT = "shell.overlay";
/** This entry's cell key in the overlay list. */
export declare const ENTRY_ID = "dsh-setup";
/** Ascending display order: below dsh-profiles (9_999) and dsh-login (10_000). */
export declare const ENTRY_ORDER = 9998;
/**
 * Services required before mounting. `loginSession` is required because the
 * wizard waits for sign-in: until then the login gate covers the app.
 */
export declare const inject: string[];
/**
 * Client plugin body.
 * @param ctx - the browser cordis context carrying the slot registry and session.
 */
export declare function apply(ctx: ClientContext): void;
