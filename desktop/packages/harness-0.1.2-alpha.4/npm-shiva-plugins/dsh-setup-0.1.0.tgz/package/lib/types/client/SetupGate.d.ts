import type { ReactNode } from 'react';
import type { LoginSessionFace } from './context-types.ts';
/** Props of {@link SetupGate}. */
export interface SetupGateProps {
    /** The read face of `ctx.loginSession`. */
    session: LoginSessionFace;
}
/**
 * The wizard.
 * @param props - the login session face.
 * @returns the cover, or null when nothing needs configuring.
 */
export declare function SetupGate({ session }: SetupGateProps): ReactNode;
