/**
 * dsh-setup host half: the routes behind the first-run setup wizard.
 *
 * The wizard (the client half) covers the app until every tool that needs a
 * model is configured: the chat model, the image generator, and — when the
 * active profile loads it — the optional OpenViking memory. This half tests
 * each key and stores what it owns; see {@link createSetupHandler} for where
 * every value goes. The only state it introduces is the completion marker, the
 * `shiva-setup` section of this machine's `settings.yaml`.
 * @module dsh-setup
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { StoredMarker } from './services.ts';
export { createSetupHandler } from './handler.ts';
export type { HandlerOptions } from './handler.ts';
export { planSetup, SETUP_VERSION } from './plan.ts';
export type { SetupFacts, SetupPlan, StepId } from './plan.ts';
export { CHAT_PROVIDERS, deriveKeyRef, IMAGE_PROVIDERS, MEMORY_PRESETS } from './providers.ts';
export { isHttpUrl, joinUrl, probeChat, probeCompletion, probeEmbedding, probeOpenRouterKey, } from './probes.ts';
export type { FetchLike, ProbeResult } from './probes.ts';
export type * from './services.ts';
export * from './wire.ts';
/** Loader-visible plugin name; the entry `id` in cordis.patch.yml stays independent. */
export declare const name = "dsh-setup";
/** Requires the HTTP route registry; every other service is read per request. */
export declare const inject: string[];
/** The settings namespace holding the completion marker. */
export declare const MARKER_NAMESPACE = "shiva-setup";
/** Schema of the completion marker section. */
export declare const MARKER_SCHEMA: z<StoredMarker>;
/** Plugin config. */
export interface Config {
    /** Deadline of each key test, in milliseconds. */
    timeoutMs?: number;
    /** How long a chat route declared by the wizard may take to register, in milliseconds. */
    routeWaitMs?: number;
    /** OpenRouter API base the image key is checked against. */
    openrouterBaseUrl?: string;
}
export declare const Config: z<Config>;
/**
 * Register the completion marker section and the wizard routes.
 * @param ctx - the host cordis context.
 * @param config - the validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
