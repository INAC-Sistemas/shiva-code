import type { ReactNode } from 'react';
import type { MemoryStatus } from '../api.ts';
import type { MemoryChoice } from '../../wire.ts';
/** Props of {@link MemoryStep}. */
export interface MemoryStepProps {
    /** `dsh-openviking`'s status. */
    status: MemoryStatus;
    /** Whether `OPENROUTER_API_KEY` resolves (possibly stored by an earlier step). */
    openrouterKey: boolean;
    /**
     * Called when the person saved or skipped the memory.
     * @param choice - what they decided.
     * @param label - what the summary shows.
     */
    onDone: (choice: MemoryChoice, label: string) => void;
    /** Return to the previous step. */
    onBack: () => void;
}
/**
 * Render the memory step.
 * @param props - the plugin status and navigation callbacks.
 * @returns the step body and actions.
 */
export declare function MemoryStep({ status, openrouterKey, onDone, onBack }: MemoryStepProps): ReactNode;
