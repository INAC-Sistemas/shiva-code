import type { ReactNode } from 'react';
import type { MemoryChoice } from '../../wire.ts';
/** One configured tool as the summary lists it. */
export interface SummaryRow {
    label: string;
    value: string;
}
/** Props of {@link SummaryStep}. */
export interface SummaryStepProps {
    rows: SummaryRow[];
    /** The memory step's outcome, or null when it was not offered. */
    memory: MemoryChoice | null;
    /** Called after completion was recorded. */
    onFinish: () => void;
    /** Return to the previous step. */
    onBack: () => void;
}
/**
 * Render the summary.
 * @param props - the rows, the memory outcome and navigation callbacks.
 * @returns the step body and actions.
 */
export declare function SummaryStep({ rows, memory, onFinish, onBack }: SummaryStepProps): ReactNode;
