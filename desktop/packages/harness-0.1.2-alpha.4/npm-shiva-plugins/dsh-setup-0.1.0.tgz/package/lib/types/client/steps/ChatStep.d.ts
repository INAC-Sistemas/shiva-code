import type { ReactNode } from 'react';
import type { SetupState } from '../../wire.ts';
/** Props of {@link ChatStep}. */
export interface ChatStepProps {
    /** The current default chat selection. */
    chat: SetupState['chat'];
    /**
     * Called once the step holds a working chat model.
     * @param label - what the summary shows.
     */
    onDone: (label: string) => void;
}
/**
 * Render the chat step.
 * @param props - the current selection and the completion callback.
 * @returns the step body and actions.
 */
export declare function ChatStep({ chat, onDone }: ChatStepProps): ReactNode;
