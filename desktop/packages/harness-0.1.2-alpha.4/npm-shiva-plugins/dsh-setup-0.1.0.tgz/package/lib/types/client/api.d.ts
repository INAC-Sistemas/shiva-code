/**
 * The same-origin calls the wizard makes.
 *
 * Three hosts answer them: this plugin's own routes, and the `dsh-assets` and
 * `dsh-openviking` routes, which remain the single writers of their settings.
 * Those two plugins answer failures as `{ ok: false, error }`; this module
 * reads both spellings so every step shows one kind of message.
 * @module dsh-setup/client/api
 */
import type { FailureResult } from '../wire.ts';
/** `dsh-assets` status: its saved settings. */
export interface AssetsStatus {
    ok: true;
    settings: {
        provider: string;
        imageModel: string;
    };
}
/** `dsh-assets` model listing for one provider and kind. */
export interface AssetsModels {
    ok: true;
    models: string[];
}
/** `dsh-openviking` status. */
export interface MemoryStatus {
    ok: true;
    configured: boolean;
    installed: boolean;
    phase: string;
    openrouterKey: boolean;
}
/** `dsh-openviking` OpenRouter model listing. */
export interface MemoryModels {
    ok: true;
    embedding: string[];
    vision: string[];
}
/** The `dsh-assets` status route. */
export declare const ASSETS_STATUS = "/assets/api/status";
/** The `dsh-assets` model listing route. */
export declare const ASSETS_MODELS = "/assets/api/models";
/** The `dsh-assets` settings route. */
export declare const ASSETS_CONFIG = "/assets/api/config";
/** The `dsh-openviking` status route. */
export declare const MEMORY_STATUS = "/openviking/api/status";
/** The `dsh-openviking` model listing route. */
export declare const MEMORY_MODELS = "/openviking/api/models";
/** The `dsh-openviking` settings route. */
export declare const MEMORY_CONFIGURE = "/openviking/api/configure";
/**
 * POST JSON to a same-origin route.
 * @param path - the route.
 * @param body - the request body.
 * @param signal - aborts the request.
 * @returns the answer when it is `ok: true`, otherwise a failure with its message.
 */
export declare function post<T extends {
    ok: true;
}>(path: string, body?: unknown, signal?: AbortSignal): Promise<T | FailureResult>;
/**
 * Read another plugin's status route, telling "not loaded" apart from a failure.
 * @param path - the status route.
 * @param signal - aborts the request.
 * @returns the status, or null when the plugin does not serve the route (not
 * loaded by the active profile) or could not answer.
 */
export declare function pluginStatus<T extends {
    ok: true;
}>(path: string, signal?: AbortSignal): Promise<T | null>;
