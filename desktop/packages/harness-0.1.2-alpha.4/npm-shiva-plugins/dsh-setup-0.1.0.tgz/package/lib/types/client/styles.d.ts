/**
 * The inline style vocabulary of the wizard.
 *
 * Inline rather than a CSS module so the bundle carries no CSS pipeline; every
 * value is a DSH design token, so the wizard follows the active theme. The card
 * matches dsh-profiles' picker, because the two screens follow each other on a
 * first run and should read as one product.
 * @module dsh-setup/client/styles
 */
import type { CSSProperties } from 'react';
/** Covers the app outright: nothing behind it is usable before setup. */
export declare const BACKDROP: CSSProperties;
export declare const CARD: CSSProperties;
export declare const EYEBROW: CSSProperties;
export declare const TITLE: CSSProperties;
export declare const SUBTITLE: CSSProperties;
/** The progress rail: one segment per step. */
export declare const PROGRESS: CSSProperties;
export declare const SEGMENT: CSSProperties;
export declare const SEGMENT_DONE: CSSProperties;
/** Provider choices: two columns, one on a narrow window. */
export declare const GRID: CSSProperties;
export declare const CHOICE: CSSProperties;
export declare const CHOICE_SELECTED: CSSProperties;
export declare const CHOICE_HINT: CSSProperties;
export declare const FIELD: CSSProperties;
export declare const LABEL: CSSProperties;
export declare const INPUT: CSSProperties;
export declare const CHECK_ROW: CSSProperties;
export declare const NOTE: CSSProperties;
export declare const ERROR: CSSProperties;
/** The summary rows. */
export declare const SUMMARY_ROW: CSSProperties;
export declare const SUMMARY_VALUE: CSSProperties;
/** The actions row: back on the left, the committing actions on the right. */
export declare const FOOTER: CSSProperties;
export declare const SPACER: CSSProperties;
export declare const PRIMARY: CSSProperties;
export declare const SECONDARY: CSSProperties;
export declare const LINK: CSSProperties;
