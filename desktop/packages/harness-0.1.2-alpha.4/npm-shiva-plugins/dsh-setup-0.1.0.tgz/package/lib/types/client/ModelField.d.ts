import type { ReactNode } from 'react';
import type { ModelOption } from '../wire.ts';
/** Props of {@link ModelField}. */
export interface ModelFieldProps {
    /** Ties the label to the input; the list derives its own id from it. */
    id: string;
    label: string;
    /** The id currently in the field, typed or picked. */
    value: string;
    /** What the route offers. An empty list leaves the field a plain input. */
    options: readonly ModelOption[];
    placeholder: string;
    disabled?: boolean;
    /**
     * Called on every keystroke and on every pick.
     * @param value - the id the field now holds.
     */
    onChange: (value: string) => void;
}
/**
 * Match against the typed text, so a long catalog narrows as one types. The
 * whole list is offered while the field still holds what was picked, because
 * that text is a complete id, not a search.
 * @param options - what the route offers.
 * @param query - the text in the field.
 * @returns the entries to list.
 */
export declare function suggest(options: readonly ModelOption[], query: string): readonly ModelOption[];
/**
 * Render the field with its suggestion list.
 * @param props - the field's label, current id, offered ids and change handler.
 * @returns the labelled field.
 */
export declare function ModelField({ id, label, value, options, placeholder, disabled, onChange }: ModelFieldProps): ReactNode;
