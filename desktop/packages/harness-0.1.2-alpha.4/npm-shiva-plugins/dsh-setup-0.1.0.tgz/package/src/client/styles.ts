/**
 * The inline style vocabulary of the wizard.
 *
 * Inline rather than a CSS module so the bundle carries no CSS pipeline; every
 * value is a DSH design token, so the wizard follows the active theme. The card
 * matches dsh-profiles' picker, because the two screens follow each other on a
 * first run and should read as one product.
 * @module dsh-setup/client/styles
 */
import type { CSSProperties } from 'react'

/**
 * Covers the app outright: nothing behind it is usable before setup.
 *
 * `safe center` on the block axis, never plain centering: a card taller than
 * the window would be centered past the scroll origin, putting its top — the
 * progress rail, the title and the first fields — above the scrollable area,
 * where no scrollbar reaches. Overflowing, the card starts at the top instead
 * and this element scrolls the whole of it.
 */
export const BACKDROP: CSSProperties = {
  position: 'absolute',
  inset: 0,
  display: 'grid',
  alignItems: 'safe center',
  justifyItems: 'center',
  padding: 24,
  overflow: 'auto',
  fontFamily: 'var(--dsw-font-family)',
  background: 'var(--dsw-alias-bg-base)',
}

export const CARD: CSSProperties = {
  position: 'relative',
  width: '100%',
  maxWidth: 640,
  boxSizing: 'border-box',
  display: 'flex',
  flexDirection: 'column',
  gap: 16,
  padding: 32,
  borderRadius: 24,
  border: '1px solid var(--dsw-alias-border-inverted)',
  background: 'var(--dsw-alias-bg-layer-2)',
  boxShadow: 'var(--dsw-shadow-lv3)',
}

export const EYEBROW: CSSProperties = {
  margin: 0,
  color: 'var(--dsw-alias-label-tertiary)',
  fontSize: 12,
  fontWeight: 600,
  letterSpacing: 0.4,
  textTransform: 'uppercase',
}

export const TITLE: CSSProperties = {
  margin: 0,
  color: 'var(--dsw-alias-label-primary)',
  fontSize: 22,
  fontWeight: 600,
  lineHeight: '30px',
}

export const SUBTITLE: CSSProperties = {
  margin: 0,
  color: 'var(--dsw-alias-label-secondary)',
  fontSize: 13,
  lineHeight: '20px',
}

/** The progress rail: one segment per step. */
export const PROGRESS: CSSProperties = {
  display: 'flex',
  gap: 6,
}

export const SEGMENT: CSSProperties = {
  flex: 1,
  height: 4,
  borderRadius: 2,
  background: 'var(--dsw-alias-border-l2)',
}

export const SEGMENT_DONE: CSSProperties = {
  ...SEGMENT,
  background: 'var(--dsw-alias-brand-primary)',
}

/** Provider choices: two columns, one on a narrow window. */
export const GRID: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
  gap: 8,
}

/**
 * The provider grid, capped so a long list scrolls instead of pushing the key
 * field and the actions below the fold. The cap is about three rows at the
 * card's width — nine providers there, fewer on a narrow window — and a list
 * that fits shows no scrollbar at all.
 */
export const GRID_SCROLL: CSSProperties = {
  ...GRID,
  maxHeight: 196,
  overflowY: 'auto',
  // Clearance so the scrollbar never sits on a card's border.
  paddingRight: 4,
}

export const CHOICE: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'flex-start',
  gap: 2,
  minWidth: 0,
  padding: '10px 12px',
  borderRadius: 12,
  border: '1px solid var(--dsw-alias-border-l2)',
  background: 'var(--dsw-alias-bg-layer-3)',
  color: 'var(--dsw-alias-label-primary)',
  fontFamily: 'inherit',
  fontSize: 14,
  textAlign: 'left',
  cursor: 'pointer',
}

export const CHOICE_SELECTED: CSSProperties = {
  ...CHOICE,
  borderColor: 'var(--dsw-alias-brand-primary)',
  boxShadow: 'inset 0 0 0 1px var(--dsw-alias-brand-primary)',
}

/**
 * A choice pinned below {@link GRID_SCROLL} instead of inside it: one row, name
 * and hint side by side, so it reads as an action rather than a thirty-first
 * card.
 */
export const CHOICE_ROW: CSSProperties = {
  ...CHOICE,
  flexDirection: 'row',
  alignItems: 'baseline',
  gap: 8,
}

export const CHOICE_ROW_SELECTED: CSSProperties = {
  ...CHOICE_SELECTED,
  flexDirection: 'row',
  alignItems: 'baseline',
  gap: 8,
}

export const CHOICE_HINT: CSSProperties = {
  color: 'var(--dsw-alias-label-tertiary)',
  fontSize: 11,
  lineHeight: '16px',
}

export const FIELD: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 6,
  minWidth: 0,
}

export const LABEL: CSSProperties = {
  color: 'var(--dsw-alias-label-primary)',
  fontSize: 13,
  fontWeight: 600,
  lineHeight: '20px',
}

export const INPUT: CSSProperties = {
  width: '100%',
  boxSizing: 'border-box',
  padding: '8px 12px',
  borderRadius: 10,
  border: '1px solid var(--dsw-alias-border-l2)',
  background: 'var(--dsw-specific-input-major, var(--dsw-alias-bg-layer-3))',
  color: 'var(--dsw-alias-label-primary)',
  fontFamily: 'inherit',
  fontSize: 14,
  lineHeight: '20px',
}

export const CHECK_ROW: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  color: 'var(--dsw-alias-label-primary)',
  fontSize: 13,
  cursor: 'pointer',
}

export const NOTE: CSSProperties = {
  margin: 0,
  color: 'var(--dsw-alias-label-secondary)',
  fontSize: 12,
  lineHeight: '18px',
}

export const ERROR: CSSProperties = {
  margin: 0,
  color: 'var(--dsw-alias-label-error, #d64545)',
  fontSize: 13,
  lineHeight: '20px',
  whiteSpace: 'pre-wrap',
  overflowWrap: 'anywhere',
}

/** The summary rows. */
export const SUMMARY_ROW: CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  gap: 12,
  padding: '10px 14px',
  borderRadius: 12,
  border: '1px solid var(--dsw-alias-border-l2)',
  background: 'var(--dsw-alias-bg-layer-3)',
  color: 'var(--dsw-alias-label-primary)',
  fontSize: 13,
}

export const SUMMARY_VALUE: CSSProperties = {
  color: 'var(--dsw-alias-label-secondary)',
  textAlign: 'right',
  overflowWrap: 'anywhere',
}

/** The actions row: back on the left, the committing actions on the right. */
export const FOOTER: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  flexWrap: 'wrap',
  gap: 12,
  marginTop: 4,
}

export const SPACER: CSSProperties = { flex: 1 }

export const PRIMARY: CSSProperties = {
  padding: '8px 16px',
  borderRadius: 10,
  border: 'none',
  background: 'var(--dsw-alias-brand-primary)',
  color: 'var(--dsw-alias-brand-primary-invert, #fff)',
  fontFamily: 'inherit',
  fontSize: 13,
  fontWeight: 600,
  lineHeight: '20px',
  cursor: 'pointer',
}

export const SECONDARY: CSSProperties = {
  padding: '8px 12px',
  borderRadius: 10,
  border: '1px solid var(--dsw-alias-border-l2)',
  background: 'none',
  color: 'var(--dsw-alias-label-secondary)',
  fontFamily: 'inherit',
  fontSize: 13,
  lineHeight: '20px',
  cursor: 'pointer',
}

export const LINK: CSSProperties = {
  padding: '8px 0',
  border: 'none',
  background: 'none',
  color: 'var(--dsw-alias-label-secondary)',
  fontFamily: 'inherit',
  fontSize: 13,
  lineHeight: '20px',
  cursor: 'pointer',
}
