import type { ReactNode } from 'react';
/**
 * Render the live clock.
 *
 * The tick re-arms on each second boundary instead of running a fixed 1000 ms
 * interval, so the displayed second never drifts behind the wall clock; the
 * timer is cleared on unmount, which is also the plugin's unload path.
 * @returns the `HH:MM:SS` reading for the current second.
 */
export declare function Clock(): ReactNode;
