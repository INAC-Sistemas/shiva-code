import type { ClientContext } from '../context-types.ts';
/** The seat this plugin contributes into. */
export declare const UTILITIES_SLOT = "conversation.session.header.utilities";
/** This entry's cell key in that list slot. */
export declare const ENTRY_ID = "dsh-clock";
/** Ascending display order; below the shipped "Session log" entry's implicit 0. */
export declare const ENTRY_ORDER = -100;
/** Services required before mounting; provided by the client runtime. */
export declare const inject: string[];
/**
 * Client plugin body.
 * @param ctx - the browser cordis context carrying the slot registry.
 */
export declare function apply(ctx: ClientContext): void;
