/**
 * Structural types for the browser cordis services this plugin consumes.
 *
 * A plugin outside the DSH monorepo's single cordis instance never receives
 * the upstream `declare module` augmentations, so the faces below mirror the
 * runtime members this half actually touches — the slot registry and nothing
 * else — and drift from upstream is contained to this file.
 *
 * This module must stay free of Node.js and React value imports: it is
 * compiled into the browser bundle, where the purity gate rejects everything
 * but the shared module-table entries.
 * @module dsh-login/client/context-types
 */
import type { ReactNode } from 'react'

/** A slot component as the registry stores it: props in, rendered output out. */
export type SlotComponent = (props: Record<string, unknown>) => ReactNode

/** The list-slot registration options this plugin passes to `slots.register`. */
export interface SlotListRegisterOptions {
  /** Declared SlotMap key being contributed into. */
  name: string
  /** This entry's cell key: a fresh id is added beside the shipped entries. */
  id: string
  /** Position among the entries, ascending (default 0). */
  order?: number
}

/** The browser SlotRegistry face (`ctx.slots`). */
export interface SlotRegistry {
  /**
   * Contribute one component into a declared slot.
   * @param options - the cell key, slot name, and display order.
   * @param component - the component rendered in that cell.
   * @returns disposer removing the contribution.
   */
  register(options: SlotListRegisterOptions, component: SlotComponent): () => void
  /**
   * Install an effect for each declaration lifetime of a slot, so a
   * registration waits for the owner that declares its seat.
   * @param key - the declared SlotMap key to depend on.
   * @param callback - creates the disposer live for that declaration.
   * @returns disposer for the wait and any active contribution.
   */
  inject(key: string, callback: () => () => void): () => void
}

/** The browser cordis context after the client runtime provides its services. */
export interface ClientContext {
  slots: SlotRegistry
  /**
   * Register a service under `name`, reachable by any plugin that declares it
   * in `inject`. The registration is an effect on this plugin's fiber, so
   * unloading the plugin withdraws the service.
   * @param name - the service name.
   * @param value - the published implementation.
   * @returns disposer unregistering the service.
   */
  provide(name: string, value: unknown): () => void
  /**
   * Install an effect for this plugin's lifetime.
   * @param callback - runs now and returns its disposer.
   * @param label - diagnostic name for the effect.
   * @returns disposer running the callback's own.
   */
  effect(callback: () => () => void, label?: string): () => void
}
