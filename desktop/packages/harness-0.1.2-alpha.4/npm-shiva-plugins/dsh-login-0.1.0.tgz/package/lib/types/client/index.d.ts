import type { ClientContext } from './context-types.ts';
export { LoginGate } from './LoginGate.tsx';
export type { LoginGateProps } from './LoginGate.tsx';
export { browserStorage, clearSession, readSession, STORAGE_KEY, writeSession } from './session.ts';
export type { StorageLike, StoredSession } from './session.ts';
export { LoginSession, provideLoginSession, SERVICE_NAME } from './service.ts';
export { SessionStore } from './store.ts';
export type { Clock } from './store.ts';
export type { LoginSessionContract } from './contract.ts';
export type { ClientContext, SlotComponent, SlotListRegisterOptions, SlotRegistry } from './context-types.ts';
/** The seat this plugin contributes into. */
export declare const OVERLAY_SLOT = "shell.overlay";
/** This entry's cell key in that list slot. */
export declare const ENTRY_ID = "dsh-login";
/** Ascending display order; high enough that the gate covers other overlay entries. */
export declare const ENTRY_ORDER = 10000;
/** Services required before mounting; provided by the client runtime. */
export declare const inject: string[];
/**
 * Client plugin body.
 *
 * The store is created here and handed to both halves: `provideLoginSession`
 * publishes its read face as `ctx.loginSession` for every other plugin, and
 * the gate keeps the object itself, which is what lets it grant a session.
 * Creating it here keeps that split explicit — there is no resolution order to
 * get wrong, and no write path on the published service.
 * @param ctx - the browser cordis context carrying the slot registry.
 */
export declare function apply(ctx: ClientContext): void;
