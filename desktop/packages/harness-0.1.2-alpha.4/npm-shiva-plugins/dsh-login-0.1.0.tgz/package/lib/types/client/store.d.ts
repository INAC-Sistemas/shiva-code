import type { StorageLike, StoredSession } from './session.ts';
import type { AuthenticatedSession } from '../wire.ts';
/** Reads the current instant; injected so expiry is testable without waiting. */
export type Clock = () => number;
/** The live session, with the transitions that change it. */
export declare class SessionStore {
    private readonly storage;
    private readonly now;
    private current;
    private readonly listeners;
    private timer;
    /**
     * Hydrate from storage, so an already-signed-in reload never flashes the gate.
     * @param storage - the browser storage, or undefined where none exists.
     * @param now - the browser clock.
     */
    constructor(storage: StorageLike | undefined, now?: Clock);
    /**
     * Subscribe to session changes.
     * @param listener - called after every change, with no arguments.
     * @returns disposer removing the subscription.
     */
    subscribe(listener: () => void): () => void;
    /**
     * The current session.
     * @returns the live session, or null while nobody is signed in. The
     * reference is stable until the session changes.
     */
    getSnapshot(): StoredSession | null;
    /**
     * Record a granted session and persist it.
     * @param session - the session the host granted.
     */
    grant(session: AuthenticatedSession): void;
    /** Drop the session here and in storage. */
    signOut(): void;
    /**
     * Adopt what storage now holds, after another tab wrote the row. A row that
     * did not change leaves subscribers alone.
     */
    sync(): void;
    /** Release the expiry timer and the subscriptions. */
    dispose(): void;
    /**
     * Publish one transition.
     * @param next - the session that now holds.
     */
    private settle;
    /** Schedule the expiry of the current session, if it has one. */
    private arm;
    /** Cancel a scheduled expiry. */
    private disarm;
}
