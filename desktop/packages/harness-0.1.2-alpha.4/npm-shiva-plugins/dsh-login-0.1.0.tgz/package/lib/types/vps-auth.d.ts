import type { CredentialKey, CredentialProvider, CredentialRecord, GrantRecord } from '@deepseek-ai/dsh-credentials';
import type { AuthenticatedSession } from './wire.ts';
/** Record scope: this plugin's registered name, as the seam's addressing requires. */
export declare const LOGIN_RECORD_SCOPE = "dsh-login";
/** Record id within the scope. Names what the record is, not where it points. */
export declare const LOGIN_RECORD_ID = "session";
/**
 * The address of the stored session.
 * @returns the `dsh-login/session` credential key.
 */
export declare function loginRecordKey(): CredentialKey;
/**
 * The grant payload this plugin owns. Opaque to the seam and to every other
 * plugin; readable only through {@link readGrantPayload}.
 */
export interface LoginGrantPayload {
    /** The token the login service returned. */
    token: string;
    /** Instant after which the session is over, or null when it has no expiry of its own. */
    expiresAt: number | null;
    /** Everything the login service's answer carried besides the token. */
    user: unknown;
}
/**
 * The credential-provider methods this module uses, and no others. Taking the
 * three methods rather than a `Context` keeps the module callable from a test
 * with an object literal, and keeps it from reaching anything ambient.
 */
export type LoginCredentialStore = Pick<CredentialProvider, 'readRecord' | 'modifyRecord' | 'deleteRecord'>;
/** Why there is no usable authorization, or the header when there is one. */
export type LoginAuthorization = {
    ok: true;
    authorization: string;
    expiresAt: number | null;
} | {
    ok: false;
    reason: 'no-store' | 'absent' | 'expired' | 'malformed';
    message: string;
};
/**
 * Build the record for one granted session.
 * @param session - the session the login service granted.
 * @param now - the host clock, applied to the session's relative lifetime.
 * @returns the grant record to store.
 */
export declare function toGrantRecord(session: AuthenticatedSession, now: number): GrantRecord;
/**
 * Read a stored record as this plugin's payload. The record is a durable
 * boundary, so every field is checked rather than trusted; a record of another
 * kind belongs to another writer and reads as nothing.
 * @param record - what the store holds at {@link loginRecordKey}, if anything.
 * @returns the payload, or undefined when there is none this plugin can use.
 */
export declare function readGrantPayload(record: CredentialRecord | undefined): LoginGrantPayload | undefined;
/**
 * Resolve the authorization header for one operation.
 *
 * Consumers call this per operation and never cache the result: that
 * per-operation read is what makes a sign-in, a sign-out, or a re-login reach
 * the next operation without a restart.
 * @param store - the credential store, or undefined where none is mounted.
 * @param now - the host clock, compared against the stored expiry.
 * @returns the header to send, or the named reason there is none.
 */
export declare function resolveLoginAuthorization(store: LoginCredentialStore | undefined, now: number): Promise<LoginAuthorization>;
/**
 * Record a granted session, replacing whatever was stored.
 *
 * A re-login replaces rather than merges: the previous grant is retired the
 * moment a new one exists, and carrying any of its fields forward would let a
 * stale expiry outlive the token it described.
 * @param store - the credential store to write through.
 * @param session - the session the login service granted.
 * @param now - the host clock, applied to the session's relative lifetime.
 */
export declare function publishGrant(store: LoginCredentialStore, session: AuthenticatedSession, now: number): Promise<void>;
/**
 * Retire the stored session, but only for the caller that presents its token.
 *
 * The same-origin fence on the routes is a cross-site defence, not
 * authentication — a caller with neither `Sec-Fetch-Site` nor `Origin` passes —
 * so an unconditional delete would let any local process end the host's
 * session. Hence read, compare, delete.
 *
 * Accepted race: a sign-in landing between the read and the delete has its
 * fresh record removed. It is self-healing (the browser still holds its token
 * and the next request re-publishes) and the seam offers no compare-and-delete
 * primitive — `modifyRecord` returning undefined means *leave untouched*, not
 * *delete*.
 * @param store - the credential store to write through.
 * @param bearer - the incoming `authorization` header, with or without the `Bearer ` prefix.
 * @returns whether a record was actually removed.
 */
export declare function revokeGrant(store: LoginCredentialStore, bearer: string): Promise<boolean>;
