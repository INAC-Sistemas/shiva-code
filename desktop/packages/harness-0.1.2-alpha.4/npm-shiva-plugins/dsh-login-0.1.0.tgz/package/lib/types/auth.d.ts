/**
 * The credential exchange, as pure functions over data: what the browser is
 * allowed to post, what this plugin sends to the login endpoint, and how that
 * endpoint's answer becomes a session or a named failure.
 *
 * Both ends of the exchange are untrusted input — one arrives over HTTP from a
 * page, the other over HTTP from another service — so every field is validated
 * here rather than assumed from a type.
 * @module dsh-login/auth
 */
import type { AuthenticateResult, Credentials } from './wire.ts';
/** A rejected browser request; the route answers it as a 400. */
export declare class LoginRequestError extends Error {
    constructor(message: string);
}
/** The field names the login endpoint expects in its JSON body. */
export interface CredentialFields {
    /** Field carrying the identifier (`email`, `username`, …). */
    identifierField: string;
    /** Field carrying the secret. */
    passwordField: string;
}
/** How an endpoint answer is read. */
export interface AnswerReading {
    /** Dot path to the token inside the answer (`token`, `data.accessToken`, …). */
    tokenPath: string;
    /** Lifetime handed to the browser with a granted session. */
    lifetimeMs: number | null;
}
/** One upstream answer, already read off the wire. */
export interface UpstreamAnswer {
    status: number;
    /** Parsed JSON body, or undefined when the answer was not JSON. */
    body: unknown;
}
/**
 * Validate one posted login attempt.
 *
 * Blank fields are refused here instead of at the endpoint: an empty password
 * is never a login, and forwarding it spends a request and an audit-log row on
 * a user who has simply not typed yet.
 * @param body - the parsed request body.
 * @returns the validated credentials.
 * @throws LoginRequestError when either field is missing, not a string, or blank.
 */
export declare function parseCredentials(body: unknown): Credentials;
/**
 * Map the credentials onto the field names the endpoint expects.
 * @param credentials - the validated attempt.
 * @param fields - the configured field names.
 * @returns the JSON body to post.
 */
export declare function buildUpstreamPayload(credentials: Credentials, fields: CredentialFields): Record<string, string>;
/**
 * Read the token out of an answer.
 *
 * Traversal is own-property only, so a path like `constructor.name` reads
 * nothing rather than a prototype member.
 * @param body - the parsed answer.
 * @param path - dot path to the token.
 * @returns the token, or undefined when the path is absent or does not hold a non-empty string.
 */
export declare function pickToken(body: unknown, path: string): string | undefined;
/**
 * Copy an answer without the value at one path.
 *
 * The copy is structural along the path only — untouched branches stay the
 * same references, which is enough because the result is serialized straight
 * back to the browser.
 * @param body - the parsed answer.
 * @param path - dot path to drop.
 * @returns the answer without that leaf, or the answer itself when the path is absent.
 */
export declare function withoutPath(body: unknown, path: string): unknown;
/**
 * Turn one endpoint answer into the route's result.
 *
 * A 2xx without a usable token is a failure, not a login: the gate exists to
 * keep unauthenticated people out, so an answer this plugin cannot read is
 * treated as a refusal and named as a misconfiguration.
 * @param answer - status and parsed body from the endpoint.
 * @param reading - the token path and the session lifetime to grant.
 * @returns the session, or the named failure.
 */
export declare function interpretUpstream(answer: UpstreamAnswer, reading: AnswerReading): AuthenticateResult;
