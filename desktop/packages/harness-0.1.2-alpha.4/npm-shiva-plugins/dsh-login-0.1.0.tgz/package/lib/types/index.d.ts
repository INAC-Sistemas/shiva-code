/**
 * dsh-login host half: the routes behind the login gate.
 *
 * The browser never talks to the login service directly. It posts the typed
 * credentials to this harness, and this plugin forwards them to the configured
 * endpoint. That keeps the endpoint URL (and any static header it needs) on
 * the host where the environment variable lives, and it keeps the exchange
 * same-origin, so no CORS grant on the login service is required for the gate
 * to work.
 *
 * Scope, stated plainly: the gate this plugin serves is a UI gate. It decides
 * what the browser renders, not what the harness serves — every other DSH
 * route stays reachable by anything that can reach the port. Bind the harness
 * to loopback, or put a real proxy in front of it, if that matters here.
 * @module dsh-login
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export type { CredentialFields, AnswerReading, UpstreamAnswer } from './auth.ts';
export { buildUpstreamPayload, interpretUpstream, LoginRequestError, parseCredentials, pickToken, withoutPath } from './auth.ts';
export { assertRevalidateInterval, assertSessionTtl, assertTimeout, resolveEndpoint, resolveLogoutEndpoint, resolveValidateEndpoint, sessionLifetime, } from './config.ts';
export { isSameOriginRequest } from './fence.ts';
export type { LoginAuthorization, LoginCredentialStore, LoginGrantPayload } from './vps-auth.ts';
export { LOGIN_RECORD_ID, LOGIN_RECORD_SCOPE, loginRecordKey, publishGrant, readGrantPayload, resolveLoginAuthorization, revokeGrant, toGrantRecord, } from './vps-auth.ts';
export { AUTHENTICATE_ROUTE, FORM_ROUTE, LOGOUT_ROUTE, VALIDATE_ROUTE } from './wire.ts';
export type { AuthenticatedSession, AuthenticateResult, Credentials, LoginError, LoginErrorCode, LoginForm, LogoutResult, ValidateResult, } from './wire.ts';
/** Loader-visible plugin name; the entry `id` in cordis.patch.yml stays independent. */
export declare const name = "dsh-login";
/** Requires the HTTP route registry (`ctx.webServer`). */
export declare const inject: string[];
/** Plugin config: where the credentials go, and what the gate says while asking for them. */
export interface Config {
    /**
     * Full URL that receives the credential POST, not a base — it is requested
     * verbatim. Overridden by the environment variable named in
     * {@link endpointEnv}, which is how a deployment points the gate somewhere
     * else without touching the profile.
     */
    endpoint?: string;
    /** Environment variable that overrides {@link endpoint} when it is set and non-blank. */
    endpointEnv?: string;
    /**
     * Full URL that ends a session at the login service, requested verbatim with
     * the signed-in user's own bearer token. Empty — the default — means the
     * service has no such route: signing out then clears the browser alone.
     */
    logoutEndpoint?: string;
    /**
     * Full URL that answers whether a token is still good, requested verbatim
     * with the browser's own bearer token. Empty — the default — means the
     * service has no such route and a stored session is never revalidated.
     */
    validateEndpoint?: string;
    /**
     * Shortest gap between two focus-driven revalidations, in milliseconds. `0`
     * revalidates on every focus, which is a request per tab switch.
     */
    revalidateIntervalMs?: number;
    /** JSON field the endpoint expects the identifier in. */
    identifierField?: string;
    /** JSON field the endpoint expects the secret in. */
    passwordField?: string;
    /** Dot path to the token inside a successful answer (`token`, `data.accessToken`, …). */
    tokenPath?: string;
    /** Static headers added to the forwarded request (a gateway key, a tenant id). */
    headers?: Record<string, string>;
    /** Deadline for the forwarded request, in milliseconds. */
    timeoutMs?: number;
    /**
     * How long a granted session keeps the gate away, in milliseconds. `0` means
     * it stays away until the browser storage is cleared — the token's own
     * expiry is the login service's business, not this plugin's.
     */
    sessionTtlMs?: number;
    /** Heading on the login screen. */
    title?: string;
    /** Line under the heading; empty renders nothing. */
    subtitle?: string;
    /** Label of the identifier field. */
    identifierLabel?: string;
    /** Label of the secret field. */
    passwordLabel?: string;
    /** Text on the submit button. */
    submitLabel?: string;
}
export declare const Config: z<Config>;
/** Complete config after schemastery applies every field default. */
type ResolvedConfig = Required<Config>;
/**
 * Serve the form descriptor: everything the gate renders, owned by the host.
 * @param config - the resolved plugin config.
 * @returns the route handler.
 */
export declare function formHandler(config: ResolvedConfig): (req: IncomingMessage, res: ServerResponse) => void;
/**
 * Serve the credential exchange.
 *
 * A granted session is written to the credential store BEFORE the browser is
 * told, and a store that refuses fails the login: a browser holding a session
 * the host has no record of would report success and then fail every host-side
 * request, which is the silent half-state this ordering exists to prevent.
 * @param ctx - the host cordis context, for the per-request credential store.
 * @param endpoint - the resolved endpoint URL.
 * @param config - the resolved plugin config.
 * @returns the route handler.
 */
export declare function authenticateHandler(ctx: Context, endpoint: URL, config: ResolvedConfig): (req: IncomingMessage, res: ServerResponse) => Promise<void>;
/**
 * Serve the sign-out, forwarding the browser's own bearer token.
 *
 * The token is taken from the incoming `authorization` header rather than
 * stored here: this plugin keeps no session state, and the browser is the only
 * place a granted token lives.
 * @param endpoint - the resolved logout URL, or undefined when the service has none.
 * @param config - the resolved plugin config.
 * @returns the route handler.
 */
export declare function logoutHandler(ctx: Context, endpoint: URL | undefined, config: ResolvedConfig): (req: IncomingMessage, res: ServerResponse) => Promise<void>;
/**
 * Serve the token check the browser runs on boot and on focus.
 *
 * The bearer comes from the incoming header; no session is stored here. The
 * answer separates a refusal from an outage because only the first may end a
 * session.
 *
 * `revalidateIntervalMs` is enforced here rather than in the browser because
 * the client bundle receives no plugin config. The browser may ask on every tab
 * switch; a repeat check of the same token inside that window is answered from
 * the last positive result instead of calling the login service again.
 *
 * The cost, stated plainly: a token revoked at the login service keeps passing
 * revalidation until the window elapses. That is what the rate limit buys, and
 * it bounds how stale an answer can be — it does not make one authoritative.
 * The memo only ever caches a pass, never a refusal, and holds one token at a
 * time.
 * @param endpoint - the resolved validation URL, or undefined when the service has none.
 * @param config - the resolved plugin config.
 * @param now - reads the current instant; injected so the window is testable.
 * @returns the route handler.
 */
export declare function validateHandler(endpoint: URL | undefined, config: ResolvedConfig, now?: () => number): (req: IncomingMessage, res: ServerResponse) => Promise<void>;
/**
 * Register the routes.
 *
 * The endpoint is resolved and validated here so a gate pointed at a malformed
 * URL fails at load, with the operator watching, rather than locking the first
 * user out of the app.
 * @param ctx - host cordis context carrying the route registry.
 * @param config - validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
