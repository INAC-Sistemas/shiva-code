import type { AuthenticateResult, Credentials, LoginForm, LogoutResult, ValidateResult } from '../wire.ts';
/**
 * Fetch the form descriptor.
 * @param signal - aborts the request when the gate unmounts.
 * @returns the descriptor the host serves.
 * @throws Error when the route is unreachable or does not answer a descriptor.
 */
export declare function fetchForm(signal: AbortSignal): Promise<LoginForm>;
/**
 * Post one login attempt.
 *
 * A refusal is a result, not an exception: the route answers the same JSON
 * body on 401 and 502 as on success, and only a dead connection or a
 * non-JSON answer becomes the local 'unreachable' failure below.
 * @param credentials - what the user typed.
 * @param signal - aborts the request when the gate unmounts.
 * @returns the granted session, or the named failure.
 */
export declare function submitCredentials(credentials: Credentials, signal: AbortSignal): Promise<AuthenticateResult>;
/**
 * Tell the login service the session is over, forwarding the browser's own
 * bearer token through the host.
 *
 * Never throws: the browser has already signed itself out by the time this
 * runs, so a service that refuses or cannot be reached changes nothing the
 * user can act on — the outcome is a diagnostic.
 * @param token - the token being retired.
 * @returns whether the login service acknowledged it.
 */
/**
 * Ask the host whether the stored token is still good.
 *
 * Never throws, and every failure it cannot attribute to the login service is
 * reported as `unreachable`: only a refusal may end a session, so an outage
 * between here and the service must not read as one.
 * @param token - the token to check.
 * @returns whether the session still holds, and why it does not.
 */
export declare function submitValidate(token: string): Promise<ValidateResult>;
export declare function submitLogout(token: string): Promise<LogoutResult>;
