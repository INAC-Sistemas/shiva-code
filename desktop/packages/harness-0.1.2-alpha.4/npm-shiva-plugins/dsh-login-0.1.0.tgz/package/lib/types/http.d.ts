/**
 * The node:http plumbing the two routes share: a bounded JSON body reader and
 * a JSON writer. Host-only — the client bundle never imports this module.
 * @module dsh-login/http
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
/**
 * Largest credential post this plugin reads. A login body is two short
 * strings; anything larger is a mistake or an attempt to make the harness hold
 * a big buffer, and reading it to the end would be the cost either way.
 */
export declare const MAX_BODY_BYTES: number;
/**
 * Read a request body as JSON.
 * @param request - the incoming request.
 * @returns the parsed value.
 * @throws LoginRequestError when the body exceeds {@link MAX_BODY_BYTES} or is not JSON.
 */
export declare function readJsonBody(request: IncomingMessage): Promise<unknown>;
/**
 * Write one JSON answer.
 *
 * `no-store` is unconditional: both routes describe or grant a session, and
 * neither belongs in a shared cache.
 * @param response - the server response.
 * @param status - the HTTP status.
 * @param body - the value to serialize.
 */
export declare function writeJson(response: ServerResponse, status: number, body: unknown): void;
