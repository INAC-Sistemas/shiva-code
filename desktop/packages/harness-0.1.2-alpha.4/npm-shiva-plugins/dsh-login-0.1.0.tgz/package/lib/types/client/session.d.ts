/**
 * The browser's record of a granted session: one `localStorage` row read
 * synchronously on first render, so an already-signed-in reload never flashes
 * the gate.
 *
 * Every access is wrapped: `localStorage` throws outright in a browser
 * configured to block site data, and the gate must still work there — it just
 * asks again on each reload. A stored row is untrusted input like any other
 * durable value, so it is validated field by field rather than cast.
 * @module dsh-login/client/session
 */
import type { AuthenticatedSession } from '../wire.ts';
/** The `localStorage` key holding the record. Clearing it signs the browser out. */
export declare const STORAGE_KEY = "dsh-login.session";
/** The subset of the Storage interface this module uses. */
export interface StorageLike {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
/** One granted session, as persisted. */
export interface StoredSession {
    /** The token the login service returned. */
    token: string;
    /** Everything else that answer carried. */
    user: unknown;
    /** Instant (browser clock) after which the gate returns, or null for no expiry. */
    expiresAt: number | null;
}
/**
 * Read the stored session, dropping an expired or unreadable one.
 * @param storage - the browser storage, or undefined where none exists.
 * @param now - the current instant on the browser clock.
 * @returns the live session, or null when there is none.
 */
export declare function readSession(storage: StorageLike | undefined, now: number): StoredSession | null;
/**
 * Persist a granted session, turning its lifetime into an instant on this
 * browser's own clock.
 * @param storage - the browser storage, or undefined where none exists.
 * @param session - the session the host granted.
 * @param now - the current instant on the browser clock.
 * @returns the stored record (returned even when persisting failed, so the
 * gate closes for this page load either way).
 */
export declare function writeSession(storage: StorageLike | undefined, session: AuthenticatedSession, now: number): StoredSession;
/**
 * Drop the stored session.
 * @param storage - the browser storage, or undefined where none exists.
 */
export declare function clearSession(storage: StorageLike | undefined): void;
/**
 * The page's storage, or undefined where the environment has none.
 * @returns the `localStorage` object, or undefined when it is unavailable.
 */
export declare function browserStorage(): StorageLike | undefined;
