import type { StoredSession } from './session.ts';
import type { SessionStore } from './store.ts';
import type { ClientContext } from './context-types.ts';
import type { LoginSessionContract } from './contract.ts';
import type { LogoutResult } from '../wire.ts';
/** The service name other plugins inject. */
export declare const SERVICE_NAME = "loginSession";
/** Thrown by {@link LoginSession.authorizedFetch} when nobody is signed in. */
export declare class NoSessionError extends Error {
    /** Discriminant for a caller that catches without matching on the message. */
    readonly code = "NO_SESSION";
    constructor();
}
/** The published face of the shared session. */
export declare class LoginSession implements LoginSessionContract {
    private readonly store;
    /**
     * @param store - the live session this service publishes read-only.
     */
    constructor(store: SessionStore);
    /**
     * Subscribe to sign-in, sign-out, and expiry.
     * @param listener - called after every change, with no arguments.
     * @returns disposer removing the subscription.
     */
    subscribe(listener: () => void): () => void;
    /**
     * The current session.
     * @returns the live session, or null while nobody is signed in. The
     * reference is stable until the session changes.
     */
    getSnapshot(): StoredSession | null;
    /**
     * The token to send to the login service's own API.
     * @returns the token, or null while nobody is signed in.
     */
    token(): string | null;
    /**
     * Call an API that authenticates with this session, returning to the gate
     * when it says the session is over.
     *
     * The bearer is attached here and overrides any `authorization` in `init`.
     * A `401` or `403` ends the session everywhere and the response is still
     * returned; every other status, a network failure included, leaves the
     * session alone.
     * @param input - the request, as `fetch` takes it.
     * @param init - request options; any `authorization` header is replaced.
     * @returns the response, whatever its status.
     * @throws NoSessionError when nobody is signed in, before any request is made.
     */
    authorizedFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response>;
    /**
     * Issue one authorized request and act on a refusal.
     * @param input - the request, as `fetch` takes it.
     * @param init - request options; any `authorization` header is replaced.
     * @param token - the bearer to present.
     * @returns the response, whatever its status.
     */
    private send;
    /**
     * Ask the login service whether this session still holds, and end it if not.
     *
     * Only an explicit refusal ends the session. An unreachable service, a
     * timeout, and a `5xx` all leave it alone — a login service that is down must
     * not sign everyone out.
     * @returns whether a session is still in place afterwards.
     */
    revalidate(): Promise<boolean>;
    /**
     * End the session here, in storage, in every other tab, and at the login
     * service.
     *
     * The local half is synchronous and unconditional, and it runs first: a
     * login service that refuses or cannot be reached must never be able to trap
     * someone inside the app. The returned promise reports only whether the
     * service was told, and never rejects.
     * @returns whether the login service acknowledged the sign-out.
     */
    signOut(): Promise<LogoutResult>;
}
/**
 * Publish the shared session and wire the two transitions nobody asks for: the
 * `storage` event, which fires only in the *other* tabs, so signing out
 * anywhere signs out everywhere; and the store's own expiry timer, released
 * with the plugin.
 * @param ctx - the browser cordis context.
 * @param store - the live session to publish.
 */
export declare function provideLoginSession(ctx: ClientContext, store: SessionStore): void;
