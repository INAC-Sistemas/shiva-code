import type { ReactNode } from 'react';
import type { SessionStore } from './store.ts';
/** What the gate needs from the shared session: read it, and grant one. */
export interface LoginGateProps {
    /** The live session the whole app shares. */
    store: SessionStore;
}
/**
 * Render the gate.
 * @param props - the shared session store.
 * @returns the sign-in screen, or null once a live session exists.
 */
export declare function LoginGate({ store }: LoginGateProps): ReactNode;
