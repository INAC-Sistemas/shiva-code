/**
 * dsh-skill-library: contributes the plugin manager's shared skill library to
 * `ctx.skills`, authenticated as the signed-in user.
 *
 * Host-only by design — the package declares no `dsh.client`, so nothing of this
 * plugin reaches a browser. It adds a fourth provider alongside the local
 * filesystem, the packaged badge and the runtime one; the registry and the
 * `skill` tool are untouched and cannot tell the difference.
 *
 * The bodies never touch disk. They are fetched per load, held for the length of
 * the call, and reach the session only where every skill body already does — the
 * tool result. With nobody signed in the library contributes nothing, and a body
 * cannot be loaded at all.
 *
 * `dsh-login` must be mounted in the same profile: this plugin has no credential
 * of its own and reads the session that plugin records.
 *
 * A skill the selected profile does not include is not in the catalog, so the
 * `skill` tool reports it unknown without asking the library. A
 * `tools/post-execute` listener asks the body endpoint in that case, and when
 * the library answers 403 `skill-not-in-profile` it replaces the error with
 * text telling the model the profile does not cover that tool.
 * @module dsh-skill-library
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { LibrarySkillProvider, notInProfileText, type ProviderOptions } from './provider.ts';
export { parseCatalog, parseSkill, SkillLibraryFormatError, type WireSkill, type WireSummary, } from './wire.ts';
/** Loader-visible plugin name; the entry `id` in cordis.patch.yml stays independent. */
export declare const name = "dsh-skill-library";
/** Requires the skill registry (`ctx.skills`). */
export declare const inject: string[];
/**
 * Rank of every library candidate.
 *
 * Below the strongest local root (`project-dsh` is 100), so a file dropped in a
 * workspace cannot silently take over a library skill's name. The shipped
 * process skills are addressed by guessable names, and a same-named local file
 * would replace audited instructions with arbitrary ones while the catalog still
 * showed the original description.
 *
 * The cost is that those names cannot be shadowed locally at all; forking one
 * means renaming it. A deployment that wants the opposite policy sets `rank`.
 */
export declare const LIBRARY_SKILL_RANK = 50;
/** Plugin config: where the library is and how the provider identifies itself. */
export interface Config {
    /**
     * Base URL of the library's plugin routes, e.g.
     * `https://vps/api/plugins/skill-library`. Sub-paths are appended to it.
     * Plain http is refused off loopback.
     */
    endpoint: string;
    /** Provider name in the `ctx.skills` registry; unique per layer. */
    providerName?: string;
    /** `source` reported on every candidate. Prompt-visible metadata. */
    source?: string;
    /** Rank of every candidate; see {@link LIBRARY_SKILL_RANK}. */
    rank?: number;
    /**
     * Deadline for the catalog request. Short on purpose: discovery runs on the
     * agent's step boundary, so an unreachable library delays every step by this
     * much before the provider gives up.
     */
    listTimeoutMs?: number;
    /**
     * Deadline for loading one body. Longer than the catalog's: this one is an
     * explicit request from the model, not a background refresh.
     */
    getTimeoutMs?: number;
    /** Largest response accepted, in bytes. */
    maxBodyBytes?: number;
    /**
     * Load-order rules: skill name → the skills that must have been loaded
     * earlier in the same session. The `skill` tool refuses a skill whose
     * prerequisites are missing, telling the model which to load first.
     * Deployment-specific, so empty by default; the desktop's `profile` preset
     * sets the system-development pipeline order.
     */
    prerequisites?: Record<string, string[]>;
    /**
     * Static headers added to every request (a gateway key, a tenant id).
     * `authorization` is rejected: it carries the signed-in user's session and has
     * one source.
     */
    headers?: Record<string, string>;
}
export declare const Config: z<Config>;
/**
 * Register the provider.
 *
 * Every config check runs here rather than on the first lookup: a provider that
 * throws during discovery is warned and skipped, so a bad endpoint would show up
 * as skills that quietly never appear.
 * @param ctx - host cordis context carrying the skill registry.
 * @param config - validated plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
