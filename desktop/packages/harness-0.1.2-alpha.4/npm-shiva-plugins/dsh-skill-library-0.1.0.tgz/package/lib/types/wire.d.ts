/**
 * Parsing of what the skill library answers.
 *
 * The registry revalidates a definition it receives, and rejects one whose name
 * does not match the candidate it asked for. That is a backstop, not this
 * module's excuse: a body reaching the model is the product of this plugin, and
 * a field silently missing here would surface as an empty instruction block
 * rather than as an error naming the endpoint.
 * @module
 */
/** A catalog entry as the library serves it, before it becomes a candidate. */
export interface WireSummary {
    readonly name: string;
    readonly description: string;
    readonly whenToUse?: string;
    readonly modelInvocable: boolean;
    readonly userInvocable: boolean;
    readonly revision: number;
}
/** One skill with its instructions. */
export interface WireSkill extends WireSummary {
    readonly content: string;
}
/** The library answered something this plugin cannot use. */
export declare class SkillLibraryFormatError extends Error {
    constructor(message: string);
}
/**
 * Parse the catalog response.
 * @param body - the decoded JSON body of the list request.
 * @returns every entry the library published.
 * @throws SkillLibraryFormatError when the body or any entry is unusable.
 */
export declare function parseCatalog(body: unknown): WireSummary[];
/**
 * Parse one loaded skill and confirm it is the one that was asked for.
 * @param body - the decoded JSON body of the get request.
 * @param expected - the candidate name the request was made for.
 * @returns the skill with its instructions.
 * @throws SkillLibraryFormatError when the body is unusable or names another skill.
 */
export declare function parseSkill(body: unknown, expected: string): WireSkill;
