/**
 * The skill provider that reads the shared library over HTTP.
 *
 * Everything the class needs is passed in — the credential store, the fetch, the
 * clock — so its failure paths are reachable from a test without a network or a
 * mounted harness. The plugin's `apply()` is what binds them to the real context.
 * @module
 */
import type { SkillCandidate, SkillDefinition, SkillLookupOptions, SkillProvider, SkillProviderObservation } from '@deepseek-ai/dsh-skill';
import type { LoginAuthorization, LoginCredentialStore } from 'dsh-login/vps-auth';
/** How the provider reaches the library and how it identifies its skills. */
export interface ProviderOptions {
    /** Validated base URL, with a trailing slash. */
    readonly endpoint: URL;
    /** Provider name in the `ctx.skills` registry. */
    readonly providerName: string;
    /** `source` reported on every candidate; prompt-visible metadata. */
    readonly source: string;
    /** Rank of every candidate; lower wins a duplicate name within a layer. */
    readonly rank: number;
    /** Deadline for the catalog request. */
    readonly listTimeoutMs: number;
    /** Deadline for loading one body. */
    readonly getTimeoutMs: number;
    /** Largest body accepted, in bytes. */
    readonly maxBodyBytes: number;
    /** Static headers added to every request. */
    readonly headers: Readonly<Record<string, string>>;
    /** Resolves the signed-in session, per call. */
    readonly authorize: (store: LoginCredentialStore | undefined) => Promise<LoginAuthorization>;
    /** The credential store, read fresh each call because the seam may mount late. */
    readonly store: () => LoginCredentialStore | undefined;
    /** Injected for tests; defaults to the global fetch. */
    readonly fetch?: typeof globalThis.fetch;
    /** Reports a transient failure. */
    readonly warn: (message: string) => void;
}
/**
 * What the model is told when the library refuses a skill outside the selected
 * profile. Written for its reader: the answer the user needs is that their
 * profile does not cover this tool, not that the tool does not exist.
 * @param name - the skill that was refused.
 * @returns the model-facing text.
 */
export declare function notInProfileText(name: string): string;
/** What the model is told when the selected profile does not include the skill library at all. */
export declare const LIBRARY_NOT_IN_PROFILE_TEXT: string;
/**
 * Contributes the shared skill library to `ctx.skills`.
 *
 * The authorization gate that matters is in {@link LibrarySkillProvider.get}:
 * the registry caches candidates but never a definition, so every body load is a
 * fresh request with a freshly resolved credential. A candidate discovered while
 * signed in cannot produce instructions after a sign-out.
 */
export declare class LibrarySkillProvider implements SkillProvider {
    private readonly options;
    readonly name: string;
    constructor(options: ProviderOptions);
    /**
     * Discover the published catalog.
     *
     * The split between the two empty answers is whether the fact is decidable
     * without leaving the machine. Nobody signed in is authoritative — the library
     * genuinely offers this session nothing — so it is a complete, cacheable empty
     * catalog. A library that cannot be reached is not authoritative, so it is an
     * incomplete observation: the registry does not cache it, the consumer keeps
     * its last good catalog instead of telling the model the skills vanished, and
     * the next step tries again.
     * @param options - lookup options; only `signal` is used, since the library is
     *   not workspace-sensitive.
     * @returns the candidates, or an incomplete observation on a transient failure.
     */
    list(options: SkillLookupOptions): Promise<readonly SkillCandidate[] | SkillProviderObservation>;
    /**
     * Load one skill body.
     *
     * `undefined` means the library authoritatively has no such skill for this
     * session — unknown, unpublished, or nobody signed in. A throw means the
     * question could not be answered, and its text is written for the model.
     * @param candidate - the winning candidate this provider listed.
     * @param options - lookup options; `signal` cancels the request.
     * @returns the definition, or `undefined` when it is no longer loadable.
     * @throws Error when the library cannot be reached, rejects the session, or answers unusably.
     */
    get(candidate: SkillCandidate, options: SkillLookupOptions): Promise<SkillDefinition | undefined>;
    /**
     * Ask the library whether a skill the catalog does not offer is refused by
     * the selected profile.
     *
     * The `skill` tool only reaches {@link get} for names in the catalog, and the
     * catalog is already narrowed to the profile, so a skill outside it never hits
     * the body endpoint on its own. This is that call, made after the tool reported
     * the name unknown.
     * @param name - the skill name the model asked for.
     * @param signal - the caller's signal.
     * @returns true only when the library answered 403 `skill-not-in-profile`.
     */
    refusedByProfile(name: string, signal: AbortSignal | undefined): Promise<boolean>;
    /** Project one catalog entry into a registry candidate. */
    private candidateOf;
    /**
     * One authenticated GET, with the body decoded.
     * @param path - sub-path appended to the endpoint.
     * @param authorization - the `Bearer …` header value for this call.
     * @param signal - the caller's signal, raced against this plugin's deadline.
     * @param timeoutMs - this plugin's own deadline.
     * @returns the decoded JSON body.
     * @throws SkillNotFound on 404; SkillNotInProfile or PluginNotInProfile on a
     *   403 carrying `skill-not-in-profile` or `plugin-not-in-profile`; Error with
     *   model-facing text otherwise.
     */
    private request;
}
