/**
 * Load-time validation of the plugin config.
 *
 * Every check here fails the composition, not the first skill lookup. A skill
 * provider is read on the agent's step boundary, where a thrown error is a
 * warned-and-skipped provider — a bad endpoint would surface as skills that
 * quietly never appear, which is the hardest failure to trace back to a typo.
 * @module
 */
/**
 * Parse and check the library base URL.
 *
 * Plain http is refused off loopback. The bodies this endpoint serves are the
 * instructions that drive the agent, and they travel with the signed-in user's
 * bearer token attached; over http both are readable by anything on the path.
 * Loopback stays allowed because that is where the plugin manager runs in
 * development.
 * @param endpoint - the configured base URL.
 * @returns the parsed base, with a trailing slash so sub-paths append.
 * @throws Error when the value is not an absolute http(s) URL, or is http off loopback.
 */
export declare function resolveEndpoint(endpoint: string): URL;
/**
 * Reject a non-positive deadline; zero or negative would abort every request
 * before it is sent.
 * @param timeoutMs - the configured deadline.
 * @param field - config field name, for the error message.
 * @throws Error when the deadline is not a positive finite number.
 */
export declare function assertTimeout(timeoutMs: number, field: string): void;
/**
 * Reject a rank that cannot order candidates.
 * @param rank - the configured rank.
 * @throws Error when the rank is not a finite number.
 */
export declare function assertRank(rank: number): void;
/**
 * Reject a non-positive body cap; it would refuse every skill.
 * @param maxBodyBytes - the configured cap.
 * @throws Error when the cap is not a positive finite number.
 */
export declare function assertMaxBodyBytes(maxBodyBytes: number): void;
/**
 * Reject unusable static headers.
 *
 * A configured `authorization` is rejected because the request is authenticated
 * with the signed-in user's session: a leftover static token would sit in front
 * of it and silently shadow whoever is signed in.
 * @param headers - the configured static headers.
 * @throws Error when a name is not a field name, a value is blank, or the name is `authorization`.
 */
export declare function assertHeaders(headers: Record<string, string>): void;
