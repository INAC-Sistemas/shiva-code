/**
 * Load-order rules for library skills, enforced at the `skill` tool.
 *
 * A rule names the skills that must have been loaded earlier in the same
 * session before a skill may load. What "loaded" means is read from the session
 * log — a `tool/call` of the `skill` tool whose `tool/result` did not fail — so
 * the rule holds across a harness restart and needs no state of its own.
 * @module dsh-skill-library/prerequisites
 */
import type { SessionFace } from './tool-events.ts';
/** Skill name → the skills that must be loaded before it in the same session. */
export type Prerequisites = Readonly<Record<string, readonly string[]>>;
/**
 * Validate the configured rules at load.
 * @param rules - the `prerequisites` config field.
 * @returns the rules unchanged.
 * @throws Error naming the first malformed skill name, or a skill that requires itself.
 */
export declare function assertPrerequisites(rules: Prerequisites): Prerequisites;
/**
 * The skills a session has loaded successfully through the `skill` tool.
 * @param session - the calling agent's session.
 * @param skillTool - the name of the skill tool.
 * @returns the loaded skill names.
 */
export declare function loadedSkills(session: SessionFace | undefined, skillTool: string): Set<string>;
/**
 * The prerequisites of a skill not yet loaded, in configured order.
 * @param rules - the configured rules.
 * @param skill - the skill being loaded.
 * @param loaded - the skills already loaded in this session.
 * @returns the missing names; empty when the skill may load.
 */
export declare function missingPrerequisites(rules: Prerequisites, skill: string, loaded: ReadonlySet<string>): string[];
/**
 * What the model is told when a skill is refused for load order.
 * @param skill - the refused skill.
 * @param missing - its prerequisites not yet loaded.
 * @returns the model-facing text.
 */
export declare function prerequisiteText(skill: string, missing: readonly string[]): string;
